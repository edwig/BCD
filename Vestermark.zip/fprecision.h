#ifndef INC_FPRECISION
#define INC_FPRECISION

/*
 *******************************************************************************
 *
 *
 *                       Copyright (c) 2002-2006
 *                       Future Team Aps 
 *                       Denmark
 *
 *                       All Rights Reserved
 *
 *   This source file is subject to the terms and conditions of the
 *   Future Team Software License Agreement which restricts the manner
 *   in which it may be used.
 *   Mail: hve@hvks.com
 *
 *******************************************************************************
*/

/*
 *******************************************************************************
 *
 *
 * Module name     :   fprecision.h
 * Module ID Nbr   :   
 * Description     :   Arbitrary floating poiint precision class
 * --------------------------------------------------------------------------
 * Change Record   :   
 *
 * Version	Author/Date		Description of changes
 * -------  -----------		----------------------
 * 01.01		HVE/020209		Initial release
 * 01.02    HVE/030421     Use FFT for Fast multiplication. Clean up the code
 *                         Now it can be included in different compilation units
 *                         Without causing linker errors.
 * 01.03    HVE/030512     Clean up _float_precision_ftoa()
 * 01.04    HVE/030701     A bug in internal base 256 when initialize a 
 *                         float_precision with a double value has been fixed
 *                         The accuracy and speed of the trignometric function
 *                         tan(), sin() & cos() has been greatly improved.
 * 01.05    HVE/030715     Use trisection identity for cos instead of bisection
 *                         identity
 * 01.06    HVE/050121     Doxygen comments added
 * 01.07    HVE/050311     Replacing #define with inline functions
 * 01.08    HVE/060127     A precision bug in /= was fixed. The division was erroneous
 *                         done in fixed PRECISION instead of the maximum of both sides
 *
 * End of Change Record
 * --------------------------------------------------------------------------
*/


/* define version string */
static char _VF_[] = "@(#)fprecision.h 01.08 -- Copyright (C) Future Team Aps";


#include "iprecision.h"

#define MAX(x,y)  ((x)>(y)?(x):(y))
#define MIN(x,y)  ((x)>(y)?(y):(x))

/// The four different ronding modes
/// # ROUND_NEAR  Rounded result is the closest to the infinitely precise result.
/// # ROUND_DOWN  Rounded result is close to but no greater than the infinitely precise result.
/// # ROUND_UP    Rounded result is close to but no less than the infinitely precise result.
/// # ROUND ZERO  Rounded result is close to but no greater in absolute value than the infinitely precise result.
enum round_mode { ROUND_NEAR, ROUND_UP, ROUND_DOWN, ROUND_ZERO };

// The build in constant!
enum table_type { _LN2, _LN10, _PI };

// Default precision of 20 Radix digits if not specified
static const int PRECISION = 20;

// Float_precision radix. Can be either BASE_10 or BASE_256
static const int F_RADIX = BASE_10; 

//#define FDIGIT(x)     (F_RADIX == 10 ? (unsigned char)((x) - '0') : (unsigned char)(x))
//#define FCHARACTER(x) (F_RADIX == 10 ? (unsigned char)((x) + '0') : (unsigned char)(x))
//#define FCHARACTER10(x) ((unsigned char)((x) + '0'))
//#define FCARRY(x)     ((x) / F_RADIX )
//#define FSINGLE(x)    ((x) % F_RADIX )

inline unsigned char FDIGIT( char x )     { return RADIX <= 10 ? (unsigned char)( x - '0') : (unsigned char)x; }
inline unsigned char FCHARACTER( char x ) { return RADIX <= 10 ? (unsigned char)( x + '0') : (unsigned char)x; }
inline unsigned char FCHARACTER10( char x){ return (unsigned char)( x + '0'); }
inline int FCARRY( unsigned int x )       { return x / RADIX; }
inline int FSINGLE( unsigned int x )      { return x % RADIX; }


class float_precision;

// Arithmetic
static float_precision operator+( const float_precision&, const float_precision& );  // Binary
static float_precision operator+( const float_precision& );                          // Unary 
static float_precision operator-( const float_precision&, const float_precision& );  // Binary
static float_precision operator-( const float_precision& );                          // Unary
static float_precision operator*( const float_precision&, const float_precision& );  // Binary
static float_precision operator/( const float_precision&, const float_precision& );  // Binary

// Boolean Comparision Operators
static bool operator> ( const float_precision&, const float_precision& );
static bool operator< ( const float_precision&, const float_precision& );
static bool operator==( const float_precision&, const float_precision& );
static bool operator!=( const float_precision&, const float_precision& );
static bool operator>=( const float_precision&, const float_precision& );
static bool operator<=( const float_precision&, const float_precision& );

// Precision Floating point functions equivalent with the std C functions
static float_precision modf( float_precision, float_precision * );
static float_precision fmod( float_precision, float_precision );
static float_precision floor( float_precision );
static float_precision ceil( float_precision );
static float_precision fabs( float_precision );
static float_precision sqrt( float_precision );
static float_precision log10( float_precision );
static float_precision log( float_precision );
static float_precision exp( float_precision );
static float_precision pow( float_precision, float_precision );
static float_precision frexp( float_precision, int * );
static float_precision ldexp( float_precision, int );

// Trigonometric functions
static float_precision atan( float_precision );
static float_precision atan( float_precision, float_precision );
static float_precision asin( float_precision );
static float_precision acos( float_precision );
static float_precision sin( float_precision );
static float_precision cos( float_precision );
static float_precision tan( float_precision );

// Support functions. Works on float_precision 
static float_precision _float_precision_inverse( const float_precision& );
static float_precision _float_table( enum table_type, unsigned int );
static std::string _float_precision_ftoa( float_precision * );
static float_precision _float_precision_atof( const char *, unsigned int, enum round_mode );
static float_precision _float_precision_dtof( double, unsigned int, enum round_mode );

// Core Supporting functions. Works directly on string class
static int _float_precision_normalize( std::string * );
static int _float_precision_rounding( std::string *, int, unsigned int, enum round_mode );
static void _float_precision_strip_leading_zeros( std::string * );
static void _float_precision_strip_trailing_zeros( std::string * );
static void _float_precision_right_shift( std::string *, int );
static void _float_precision_left_shift( std::string *, int );
static int _float_precision_compare( std::string *, std::string * );
static std::string _float_precision_uadd_short( std::string *, unsigned int );
static std::string _float_precision_uadd( std::string *, std::string * );
static std::string _float_precision_usub_short( int *, std::string *, unsigned int );
static std::string _float_precision_usub( int *, std::string *, std::string * );
static std::string _float_precision_umul_short( std::string *, unsigned int );
static std::string _float_precision_umul( std::string *, std::string * );
static std::string _float_precision_umul_fourier( std::string *, std::string * );
static std::string _float_precision_udiv_short( unsigned int *, std::string *, unsigned int );


///
/// @class float_precision
/// @author Henrik Vestermark (hve@hvks.com)
/// @date  1/24/2005
/// @version 1.0
/// @brief  Arbitrary float precision class
///
/// @todo
///
///// Float Precision class
///   An Arbitrary float always has the format [sign][digit][.[digit]*][E[sign][digits]+] where sign is either '+' or '-'
///   And is always stored in normalized mode after an operation or conversion
///   The length or the representation is always >= 2
///   A null string is considered as an error and an exception is thrown
///   Floating Point Numbers is stored in BASE 10 or BASE 256 depends of the F_RADIX setting
///   Also number is always strip for leading nosignificant zeros
//
class float_precision {
   enum round_mode   mRmode;  // Rounding mode. Default Round Nearest
   unsigned int      mPrec;   // Number of decimals in mantissa. Default 20, We make a shot cut by assuming the number of digits can't exceed 2^32-1
   int               mExpo;   // Exponent as a power of RADIX (not 2 as in IEEE 754). We make a short cut here and use a standard int to hold 
                              // the exponent. This will allow us exponent in the range from -RADIX^2^31 to  RADIX^2^31. Which should be enough
   std::string       mNumber; // The mantissa any length however the fraction point is always after the first digit and is implied

   public:
      // Constructors
      float_precision( char, unsigned int, enum round_mode );      // When initialized through a char
      float_precision( int, unsigned int, enum round_mode );       // When initialized through a int
      float_precision( double, unsigned int, enum round_mode );    // When initialized through a double
      float_precision( const char *, unsigned int, enum round_mode );    // When initialized through a char string
      float_precision( const float_precision& s = float_precision(0, PRECISION, ROUND_NEAR) ): mNumber(s.mNumber), mRmode(s.mRmode), mPrec(s.mPrec), mExpo(s.mExpo) {}  // When initialized through another float_precision
      float_precision( const int_precision&, unsigned int, enum round_mode ); 

      // Coordinate functions
      std::string get_mantissa() const             { return mNumber; };    // Copy of mantissa
      std::string *ref_mantissa()                  { return &mNumber; }    // Reference of Mantissa
      enum round_mode mode() const                 { return mRmode; }
      enum round_mode mode( enum round_mode m )    { return( mRmode = m ); }
      int exponent() const                         { return mExpo; };
      int exponent( int e )                        { return( mExpo = e ); }  
      int sign() const                             { return CHAR_SIGN( mNumber[0] ); }
      unsigned int precision() const               { return mPrec; }
      unsigned precision( unsigned int p )         { int sign; std::string m;
                                                   sign = CHAR_SIGN( mNumber[0] );
                                                   mPrec = p > 0 ? p : PRECISION;
                                                   m = mNumber.substr(1); // Bypass sign
                                                   mExpo += _float_precision_rounding( &m, sign, mPrec, mRmode );
                                                   mNumber = SIGN_STRING( sign ) + m;
                                                   return mPrec;
                                                   }

      
      void set_n( std::string mantissa )   { mNumber = mantissa; }    // Secret function
      float_precision assign( float_precision& a )  { mRmode = a.mRmode; mPrec = a.mPrec; mExpo = a.mExpo; mNumber = a.mNumber; return *this; }


      int change_sign()   { // Change and return sign   
                          if( mNumber.length() != 2 || FDIGIT( mNumber[1] ) != 0 ) // Don't change sign for +0!
                             if( mNumber[0] == '+' ) mNumber[0] = '-'; else mNumber[0] = '+';
                          return CHAR_SIGN( mNumber[0] );
                          }

      operator int()     {// Conversion to int

                         std::string s = _float_precision_ftoa( this ); 
                         return atoi( s.c_str() ); 
                         } 

      operator double()  {// Conversion to double
                         std::string s = _float_precision_ftoa( this ); 
                         return atof( s.c_str() ); 
                         } 


      // Essential operators
      float_precision& operator= ( const float_precision& );
      float_precision& operator+=( const float_precision& );
      float_precision& operator-=( const float_precision& );
      float_precision& operator*=( const float_precision& );
      float_precision& operator/=( const float_precision& );

      // Specialization
      friend ostream& operator<<( ostream& strm, const float_precision& d ) { return strm << _float_precision_ftoa( const_cast<float_precision *>(&d) ).c_str();}
      friend istream& operator>>( istream& strm, float_precision& d )
         { char ch; std::string s; int cnt, exp_cnt;
         strm >> ws >> ch; if( ch == '+' || ch == '-' ) { s += ch; strm >> ch; } else s += '+';  // Parse sign
         for( cnt = 0; ch >= '0' && ch <= '9'; cnt++, strm >> ch ) s += ch;  // Parse integer part
         if( ch == '.' )  // Parse fraction
            for( s += '.', strm >> ch; ch >= '0' && ch <= '9'; cnt++, strm >> ch ) s += ch;   // Parse fraction part
         if( ch == 'e' || ch == 'E' )
            {
            s += 'e'; strm >> ch; if( ch == '+' || ch == '-' ) { s += ch; strm >> ch; } else s += '+';  // Parse Expo sign 
            for( exp_cnt =0; ch >= '0' && ch <= '9'; exp_cnt++, strm >> ch ) s += ch;  // Parse expo number
            }

         cin.putback( ch );  // ch contains the first character not part of the number, so put it back
         if( !strm.fail() && ( cnt > 0 || exp_cnt > 0 ) )  // Valid number 
            d = float_precision( const_cast<char *>( s.c_str() ), PRECISION, ROUND_NEAR );
         return strm;
         }

      // Exception class
      class bad_int_syntax {}; 
      class bad_float_syntax {};
      class out_of_range   {};
      class divide_by_zero {};
      class domain_error   {};
   };



//////////////////////////////////////////////////////////////////////////////////////
///
/// FLOAT PRECISION CONSTRUCTORS
///
//////////////////////////////////////////////////////////////////////////////////////


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Char constructor for float_precision
///	@return 		nothing
///	@param      "c"	-	Integer char digit
///	@param      "p"	-	Number of precision (default PRECISION)
///	@param      "m"	-	rounding mode (default ROUND_NEAR)
///
///	@todo 
///
/// Description:
///   Constructor
///   Validate and initilize with a character
///   Input Always in BASE_10
//
inline float_precision::float_precision( const char c, unsigned int p = PRECISION, enum round_mode m = ROUND_NEAR )
   {
   int i;

   if( c < '0' || c > '9' )
      throw bad_int_syntax(); 
   else
      { 
      i = c - '0';  // Convert to integer
      mNumber = "+";
      mNumber += FCHARACTER( FSINGLE( i ) );
      mExpo = 0;
      mRmode = m;
      mPrec = p;
      }
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Integer constructor for float_precision
///	@return 		nothing
///	@param      "i"	-	Integer number
///	@param      "p"	-	Number of precision (default PRECISION)
///	@param      "m"	-	rounding mode (default ROUND_NEAR)
///
///	@todo 
///
/// Description:
///   Constructor
///   Validate and initialize with integer
///   Just convert integer to string representation in BASE RADIX
///   The input integer is always BASE_10
///   Only use core base functions to create multi precision numbers
//
inline float_precision::float_precision( int i, unsigned int p = PRECISION, enum round_mode m = ROUND_NEAR )
   {
   int sign = 1;
   std::string number;

   mRmode = m;
   mPrec = p;
   mExpo = 0;

   if( i == 0 )
      {
      mNumber = "+";
      mNumber.append( 1, FCHARACTER( 0 ) );
      return;
      }

   if( i < 0 ) 
      { 
      i = -i;
      sign = -1;
      }

   if( F_RADIX == BASE_256 )  // Fast BASE_256 conversion
      {
      int j;
      unsigned char *p = (unsigned char *)&i;
      
      for( j = sizeof( int ); j > 0; j-- )
         if( p[j-1] != 0 )  // Strip leading zeros
            break;
      for( ; j > 0; j-- )
         number.append( 1, p[j-1] );
      }
   else
      {// All other BASE
      for( ; i != 0; i /= F_RADIX )
         number.insert( (std::string::size_type)0, 1, FCHARACTER( i % F_RADIX ) );
      }
 
   _float_precision_strip_leading_zeros( &number );   // First strip for leading zeros
   mExpo = number.length() -1;                         // Always one digit before the dot
   _float_precision_strip_trailing_zeros( &number );  // Get rid of trailing non-significant zeros
   mExpo += _float_precision_rounding( &number, sign, mPrec, mRmode );    // Perform rounding
   mNumber = SIGN_STRING( sign ) + number;                // Build number
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		string constructor for float_precision
///	@return 		nothing
///	@param      "str"	-	Floating point number as a string
///	@param      "p"	-	Number of precision (default PRECISION)
///	@param      "m"	-	rounding mode (default ROUND_NEAR)
///
///	@todo 
///
/// Description:
///   Constructor
///   Validate input and convert to internal representation
///   Always add sign if not specified 
///   Only use core base functions to create multi precision numbers
///   The float can be any integer or decimal float representation
//
inline float_precision::float_precision( const char *str, unsigned int p = PRECISION, enum round_mode m = ROUND_NEAR )
   {
   if( str == NULL || *str == '\0' )
      { throw bad_int_syntax(); return; }

   mRmode = m;
   mPrec = p;
   *this = _float_precision_atof( str, p, m );
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		double constructor for float_precision
///	@return 		nothing
///	@param      "d"	-	Floating point number in IEE754 format
///	@param      "p"	-	Number of precision (default PRECISION)
///	@param      "m"	-	rounding mode (default ROUND_NEAR)
///
///	@todo 
///
/// Description:
///   Constructor for double
///   Validate input and convert to internal representation
///   Always add sign if not specified 
///   Only use core base functions to create multi precision numbers
///   The float can be any integer or decimal float representation
//
inline float_precision::float_precision( double d, unsigned int p = PRECISION, enum round_mode m = ROUND_NEAR )
   {
   mRmode = m;
   mPrec = p;
   *this = _float_precision_dtof( d, p, m );
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		double constructor for float_precision
///	@return 		nothing
///	@param      "ip"	-	arbitrary integer precision 
///	@param      "p"	-	Number of precision (default PRECISION)
///	@param      "m"	-	rounding mode (default ROUND_NEAR)
///
///	@todo 
///
/// Description:
///   Constructor for int_precision to float_precision
///   Slow impl.
///    1) conver to Ascii decimal string and then 
///   2) convert it back to floating format
//
inline float_precision::float_precision( const int_precision& ip, unsigned int p = PRECISION, enum round_mode m = ROUND_NEAR )
   {
   std::string s;

   s = _int_precision_itoa( const_cast<int_precision*>(&ip) );
   mRmode = m;
   mPrec = p;
   *this = float_precision( (char *)s.c_str(), p, m );
   }

//////////////////////////////////////////////////////////////////////////////////////
///
/// END FLOAT PRECISION CONSTRUCTORS
///
//////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////
///
/// FLOAT PRECISION OPERATORS
///
//////////////////////////////////////////////////////////////////////////////////////


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Assign float precision numbers
///	@return 	float_precision&	-	
///	@param   "a"	-	float precsion number to assign
///
///	@todo
///
/// Description:
///   Assign operator
///   Round it to precision and mode of the left hand side
///   Only the exponent and mantissa is assigned
///   Mode and precision is not affected by the assignment
//
inline float_precision& float_precision::operator=( const float_precision& a )
   {
   int sign;

   mExpo = a.mExpo;   
   sign = a.sign();
   mNumber = a.mNumber.substr(1);
   if( _float_precision_rounding( &mNumber, sign, mPrec, mRmode ) != 0 )  // Round back to left hand side precision
      mExpo++;

   mNumber.insert( (std::string::size_type)0, SIGN_STRING( sign ) );

   return *this;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	+= float precision numbers
///	@return 	the resulting float_precision number
///	@param   "a"	-	float precsion number to assign
///
///	@todo    Still missing code for x += a where add make sense. fx. if a is so small it does 
///            not affect the result within the given precision is should ignored. same is true
///            if x is insignififcant comapre to a the just assign a to x
///
/// Description:
///   The essential += operator
///   1) Align to same exponent
///   2) Align to same precision
///   3) Add Mantissa
///   4) Add carry to exponent
///   4) Normalize 
///   5) Rounding to precission 
///   Early out algorithm. i.e.
///      - x+=0 return x
///      - x+=a wher x is 0 return a
//
inline float_precision& float_precision::operator+=( const float_precision& a )
   {
   int sign, sign1, sign2, wrap;
   int expo_max, digits_max;
   unsigned int precision_max;
   std::string s, s1, s2;
   
   if( a.mNumber.length() == 2 && FDIGIT( a.mNumber[1] ) == 0 )  // Add zero
      return *this;
   if( mNumber.length() == 2 && FDIGIT( mNumber[1] ) == 0 )      // Add a (not zero) to *this (is zero) Same as *this = a;
      return *this = a;

   // extract sign and unsigned portion of number
   sign1 = a.sign();
   s1 = a.mNumber.substr( 1 ); // Extract Mantissa
   sign2 = CHAR_SIGN( mNumber[0] );
   s2 = mNumber.substr( 1 );   // Extract Mantissa
   expo_max = MAX( mExpo, a.mExpo );
   precision_max = MAX( mPrec, a.precision() );

   // Check if add makes sense. Still missing
   
   // Right shift (padd leading zeros) to the smallest number
   if( a.mExpo != expo_max )
      _float_precision_right_shift( &s1, expo_max - a.mExpo );
   if( mExpo != expo_max ) 
      _float_precision_right_shift( &s2, expo_max - mExpo );

   // Round to same precision 
   if( _float_precision_rounding( &s1, sign1, precision_max, a.mode() ) != 0 ) // If carry when rounding up then one right shift
      _float_precision_right_shift( &s1, 1 );
   if( _float_precision_rounding( &s2, sign2, precision_max, mRmode ) != 0 ) // If carry when rounding up then one right shift 
      _float_precision_right_shift( &s2, 1 );

   // Alignment to same number of digits, so add can be perfomed as integer add
   digits_max = MAX( s1.length(), s2.length() );
   if( s1.length() != digits_max )
      _float_precision_left_shift( &s1, digits_max - s1.length() );
   if( s2.length() != digits_max ) 
      _float_precision_left_shift( &s2, digits_max - s2.length() );
   
   // Now s1 and s2 is aligned to the same exponent. The biggest of the two
   if( sign1 == sign2 )
      {
      s = _float_precision_uadd( &s1, &s2 );
      if( s.length() > s1.length() ) // One more digit
         expo_max++;
      sign = sign1;
      }
   else
      {
      int cmp = _float_precision_compare( &s1, &s2 );
      if( cmp > 0 ) // Since we subctract less the wrap indicater need not to be checked
         {
         s = _float_precision_usub( &wrap, &s1, &s2 );
         sign = sign1;
         }
      else
         if( cmp < 0 )
            {
            s = _float_precision_usub( &wrap, &s2, &s1 );
            sign = sign2;
            }
         else
            {  // Result zero
            sign = 1;
            s = "0"; s[0] = FCHARACTER( 0 );
            expo_max = 0;
            }
      }

   expo_max += _float_precision_normalize( &s );            // Normalize the number
   if( _float_precision_rounding( &s, sign, mPrec, mRmode ) != 0 )  // Round back left hand side precision
      expo_max++;

   mNumber = SIGN_STRING( sign ) + s;
   mExpo = expo_max;

   return *this;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	-= float precision numbers
///	@return 	the resulting float_precision number
///	@param   "a"	-	float precsion number to assign
///
///	@todo    
///
/// Description:
///   The essential -= operator
///   n = n - a is the same as n = n + (-a). so change sign and use the += operator instead
//
inline float_precision& float_precision::operator-=( const float_precision& a )
   {
   float_precision b;

   b.precision( a.precision() ); 
   b.mode( a.mode() );
   b = a;
   b.change_sign();
   *this += b;

   return *this;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	*= float precision numbers
///	@return 	the resulting float_precision number
///	@param   "a"	-	float precsion number to assign
///
///	@todo    
///
/// Description:
///   The essential *= operator
///   1) Multiply mantissa
///   2) Add exponent
///   3) Normalize
///   4) Rounding to precision
//
inline float_precision& float_precision::operator*=( const float_precision& a )
   {
   int expo_res;
   int sign, sign1, sign2;
   std::string s, s1, s2;

   // extract sign and unsigned portion of number
   sign1 = a.sign();
   s1 = a.mNumber.substr( 1 );
   sign2 = CHAR_SIGN( mNumber[0] );
   s2 = mNumber.substr( 1 );

   sign = sign1 * sign2;
   s = _float_precision_umul_fourier( &s1, &s2 );
   expo_res = mExpo + a.mExpo;
   if( s.length() - 1 > s1.length() + s2.length() - 2 ) // A carry 
      expo_res++;
   expo_res += _float_precision_normalize( &s );            // Normalize the number
   if( _float_precision_rounding( &s, sign, mPrec, mRmode ) != 0 )  // Round back left hand side precision
      expo_res++;
   
   if( sign == -1 && s.length() == 1 && FDIGIT( s[0] ) == 0 )  // Avoid -0 as result +0 is right
      sign = 1; // Change sign
   if( s.length() == 1 && FDIGIT( s[0] ) == 0 )  // Result 0 clear exponent
      expo_res = 0;

   mExpo = expo_res;
   mNumber = SIGN_STRING( sign ) + s;

   return *this;
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/27/2006
///	@brief 	/= float precision numbers
///	@return 	the resulting float_precision number
///	@param   "a"	-	float precsion number to assign
///
///	@todo    
///
/// Description:
///   The essential /= operator
///   We do a /= b as a *= (1/b)
/// Bug 
///   1/27/2006 Inverse was always done with the precision of a instead of the Max precision of both this & a
//
inline float_precision& float_precision::operator/=( const float_precision& a )
   {
   if( mNumber.length() == 2 && FDIGIT( mNumber[1] ) == 0 ) // If divisor is zero the result is zero
      return *this;

   float_precision c;

   c.precision( a.precision() );
   if( a.precision() < mPrec )
      c.precision( mPrec );
   c=a;
   *this *= _float_precision_inverse(c); 
   return *this;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	+ float precision numbers
///	@return 	the resulting float_precision number
///	@param   "a"	-	first float precsion number to add
///	@param   "b"	-	second float precsion number to add
///
///	@todo    
///
/// Description:
///   Binary add two float_precision numbers
///   Implenting using the essential += operator
//
static float_precision operator+( const float_precision& a, const float_precision& b )
   {
   float_precision c;

   c.precision( a.precision() );
   if( a.precision() < b.precision() )
      c.precision( b.precision() );

   c = a;
   c += b; 
   
   return c;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Unary + float precision number
///	@return 	the resulting float_precision number
///	@param   "a"	-	float precsion number 
///
///	@todo    
///
/// Description:
///   Unary add. Do nothing and return a
//
static float_precision operator+( const float_precision& a )
   {
   // Otherwise do nothing
   return a;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	- float precision numbers
///	@return 	the resulting float_precision number
///	@param   "a"	-	first float precsion number 
///	@param   "b"	-	second float precsion number to subtract
///
///	@todo    
///
/// Description:
///   Binary subtract two float_precision numbers
///   Implenting using the essential -= operator
//
static float_precision operator-( const float_precision& a, const float_precision& b )
   {
   unsigned int precision;
   float_precision c;

   precision = a.precision();
   if( precision < b.precision() )
      precision = b.precision();

   c.precision( precision );
   c = a;
   c -= b; 
   
   return c;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Unary - float precision number
///	@return 	the resulting float_precision number
///	@param   "a"	-	float precsion number 
///
///	@todo    
///
/// Description:
///   Unary hypen Just change sign
//
static float_precision operator-( const float_precision& a )
   {
   float_precision b;

   b.precision( a.precision() );
   b = a;
   b.change_sign();
   
   return b;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	* float precision numbers
///	@return 	the resulting float_precision number
///	@param   "a"	-	first float precsion number 
///	@param   "b"	-	second float precsion number to multiply
///
///	@todo    
///
/// Description:
///   Binary multiplying two float_precision numbers
///   Implenting using the essential *= operator
//
static float_precision operator*( const float_precision& a, const float_precision& b )
   {
   unsigned int precision;
   float_precision c;

   precision = a.precision();
   if( precision < b.precision() )
      precision = b.precision();

   c.precision( precision );

   c = a;
   c *= b; 
   
   return c;
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	/ float precision numbers
///	@return 	the resulting float_precision number
///	@param   "a"	-	first float precsion number 
///	@param   "b"	-	second float precsion number to divide
///
///	@todo    
///
/// Description:
///   Binary divide two float_precision numbers
///   Implenting using the essential /= operator
//
static float_precision operator/( const float_precision& a, const float_precision& b )
   {
   unsigned int precision;
   float_precision c;

   precision = a.precision();
   if( precision < b.precision() )
      precision = b.precision();

   c.precision( precision + 1 );

   c = a;
   c /= b;
   
   return c;
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	== float precision numberss
///	@return 	the boolean result
///	@param   "a"	-	first float precsion number 
///	@param   "b"	-	second float precsion number 
///
///	@todo    
///
/// Description:
///   If both operands has the same mantissa length and same exponent
///   and if the mantissa is identical then it's the same. 
///   However a special test of +0 == -0 is done
///   Precsion and rounding mode does not affect the comparison
//
static bool operator==( const float_precision& a, const float_precision& b )
   {
   if( const_cast<float_precision&>(a).ref_mantissa()->length() != const_cast<float_precision&>(b).ref_mantissa()->length() ||
       a.exponent() != b.exponent() ) // Different therefore false
      return false;
   else
      if( (const_cast<float_precision&>(a).ref_mantissa())->compare( *const_cast<float_precision&>(b).ref_mantissa() ) == 0 )   // Same return true
         return true;
      else
         if( const_cast<float_precision&>(a).ref_mantissa()->length() == 2 && (*const_cast<float_precision&>(a).ref_mantissa())[1] == FDIGIT(0) && (*const_cast<float_precision&>(b).ref_mantissa())[1] == FDIGIT(0) )
            return true;  // This conditions is only true if +0 is compare with -0 and therefore true
   
   return false;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	compare < float precision numbers
///	@return 	the boolean result
///	@param   "a"	-	first float precsion number 
///	@param   "b"	-	second float precsion number 
///
///	@todo    
///
/// Description:
///   1) Test for both operand is zero and return false if condition is meet
///   2) If signs differs then return the boolean result based on that
///   3) Now if same sign and one operand is zero then return the boolean result
///   4) If same sign and not zero check the exponent
///   5) If same sign and same exponent then check the mantissa for boolean result
///   Precsion and rounding mode does not affect the comparison
//
static bool operator<( const float_precision& a, const float_precision& b )
   {
   int sign1, sign2, cmp;
   bool zero1, zero2;
   
   sign1 = a.sign(); 
   sign2 = b.sign(); 

   zero1 = const_cast<float_precision&>(a).ref_mantissa()->length() == 2 && FDIGIT( ( *const_cast<float_precision&>(a).ref_mantissa())[1] ) == 0 ? true : false;
   zero2 = const_cast<float_precision&>(b).ref_mantissa()->length() == 2 && FDIGIT( ( *const_cast<float_precision&>(b).ref_mantissa())[1] ) == 0 ? true : false;

   if( zero1 == true && zero2 == true )  // Both zero
      return false;

   // Different signs
   if( sign1 < sign2 )
      return true;
   if( sign1 > sign2 )
      return false;

   // Now a &  b has the same sign
   if( zero1 == true )   // If a is zero and a & b has the same sign and b is not zero then a < b
      return true;
   if( zero2 == true )   // If b is zero and a & b has the same sign and a is not zero then a > b
      return false;

   // Same sign and not zero . Check exponent
   if( a.exponent() < b.exponent() )
      return sign1 > 0 ? true : false;
   if( a.exponent() > b.exponent() )
      return sign1 > 0 ? false: true;

   // Same sign & same exponent. Check mantissa
   cmp = (const_cast<float_precision&>(a).ref_mantissa())->compare( *const_cast<float_precision&>(b).ref_mantissa() );
   if( cmp < 0 && sign1 == 1 )
      return true;
   else
      if( cmp > 0 && sign1 == -1 )
         return true;
   
   return false;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	!= float precision numberss
///	@return 	the boolean result
///	@param   "a"	-	first float precsion number 
///	@param   "b"	-	second float precsion number 
///
///	@todo    
///
/// Description:
///   implemented negating the == comparison
//
static bool operator!=( const float_precision& a, const float_precision& b )
   {
   return b == a ? false : true;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	> float precision numberss
///	@return 	the boolean result
///	@param   "a"	-	first float precsion number 
///	@param   "b"	-	second float precsion number 
///
///	@todo    
///
/// Description:
///   Implemented using the equality a>b => b<a
//
static bool operator>( const float_precision& a, const float_precision& b )
   {
   return b < a ? true : false;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	<= float precision numberss
///	@return 	the boolean result
///	@param   "a"	-	first float precsion number 
///	@param   "b"	-	second float precsion number 
///
///	@todo    
///
/// Description:
///   Implemented using the equality a<=b => not b<a
//
static bool operator<=( const float_precision& a, const float_precision& b )
   {
   return b < a ? false : true;
   }


// Boolean >=
//
///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	>= float precision numberss
///	@return 	the boolean result
///	@param   "a"	-	first float precsion number 
///	@param   "b"	-	second float precsion number 
///
///	@todo    
///
/// Description:
///   Implemented using the equality a>=b => not a<b
//
static bool operator>=( const float_precision& a, const float_precision& b )
   {
   return a < b ? false: true;
   }


//////////////////////////////////////////////////////////////////////////////////////
///
/// END FLOAT PRECISION OPERATORS
///
//////////////////////////////////////////////////////////////////////////////////////


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate the inverse of a 
///	@return 	   float_precision -	Return 1/a
///	@param      "a"	-	The float_precision number to inverse
///
///	@todo  
///
/// Description:
///   Inverse of V
///   Using a Newton iterations Un = U(2-UV)
///   Always return the result with 2 digits higher precision that argument
///   _float_precision_inverse() return a interim result for a basic operation like /
//
static float_precision _float_precision_inverse( const float_precision& a )
   {
   unsigned int precision;
   int i, expo;
   double fv, fu;
   float_precision r, u, v, c2;
   std::string::reverse_iterator rpos;
   std::string::iterator pos;
   std::string *p;

   precision = a.precision();  
   v.precision( precision + 2 );
   v = a;
   p= v.ref_mantissa();
   if( p->length() == 2 && FDIGIT( (*p)[1] ) == 0 )
      { throw float_precision::divide_by_zero(); return a; }


   expo = v.exponent();
   v.exponent( 0 );
   r.precision( precision + 2 ); // Do iteration using 2 digits higher precision
   u.precision( precision + 2 );
   c2 = float_precision( 2, precision + 2 );

   // Get a initial guess using ordinary floating point
   rpos = v.ref_mantissa()->rbegin();
   fv = FDIGIT( (double)*rpos );
   for( rpos++; rpos+1 != v.ref_mantissa()->rend(); rpos++ )
      {
      fv *= (double)1/(double)F_RADIX;
      fv += FDIGIT( *rpos );
      }
   if( v.sign() < 0 )
      fv = -fv;
   fu = 1 / fv;

   u = float_precision( fu );
   
   // Now iterate using Netwon Un=U(2-UV)
   for(;;)
      {
      r = u * v;                 // UV
      r = c2-r;                  // 2-UV
      u *= r;                    // Un=U(2-UV)
      for( pos = r.ref_mantissa()->begin(), pos+=2, i = 0; pos != r.ref_mantissa()->end(); i++, pos++ )
         if( FDIGIT( *pos ) )
            break;

      if( pos == r.ref_mantissa()->end() || i >= precision )
         break;
      }

   u.exponent( u.exponent() - expo );
   u.mode( a.mode() );

   return u;
   }

// Float Precision support functions

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate sqrt(x)
///	@return 	   float_precision -	Return sqrt(a)
///	@param      "x"	-	The sqrt argument
///
///	@todo  
///
/// Description:
///   sqrt(V)
///   Equivalent with the same standard C function call
///   Seperate exponent. e.g. sqrt(V*10^x)=10^x/2*sqrt(V)
///   Un=0.5U(3-VU^2)
///   Then Un == 1/Sqrt(V). and sqrt(V) = VUn
//
static float_precision sqrt( const float_precision x )
   {
   unsigned int precision;
   int i, expo, expo_sq;
   double fv, fu;
   float_precision r, u, v;
   float_precision c3(3);
   float_precision c05(0.5);
   std::string::reverse_iterator rpos;
   std::string::iterator pos;
   std::string *p;

   precision = x.precision(); 
   v.precision( precision + 2 );
   v = x;
   if( v.sign() < 0 ) 
      { throw float_precision::domain_error(); return x; }
   
   p= v.ref_mantissa();
   if( p->length() == 2 && FDIGIT( (*p)[1] ) == 0 )  // Sqrt(0) is zero
      { return float_precision( 0 ); }

   expo = v.exponent();
   expo_sq = expo / 2;
   v.exponent( expo - 2 * expo_sq );
   r.precision( precision + 2 ); // Do iteration using 2 digits higher precision
   u.precision( precision + 2 );

   // Get a initial guess using ordinary floating point
   rpos = v.ref_mantissa()->rbegin();
   fv = FDIGIT( (double)*rpos );
   for( rpos++; rpos+1 != v.ref_mantissa()->rend(); rpos++ )
      {
      fv *= (double)1/(double)F_RADIX;
      fv += FDIGIT( *rpos );
      }
   if( expo - 2 * expo_sq > 0 )
      fv *= (double)F_RADIX;
   else
      if( expo - 2 * expo_sq < 0 )
         fv /= (double)F_RADIX;
   fu = 1 / sqrt( fv );

   u = float_precision( fu );
   
   // Now iterate using Netwon Un=0.5U(3-VU^2)
   for(;;)
      {
      r = v * u * u;             // VU^2
      r = c3-r;                  // 3-VU^2
      r *= c05;                  // (3-VU^2)/2
      u *= r;                    // U=U(3-VU^2)/2
      
      for( pos = r.ref_mantissa()->begin(), pos+=2, i = 0; pos != r.ref_mantissa()->end(); i++, pos++ )
         if( FDIGIT( *pos ) )
            break;

      if( pos == r.ref_mantissa()->end() || i >= precision )
         break;
      }

   u *= v;
   u.exponent( u.exponent() + expo_sq );

   // Round to same precision as argument and mrounding mode
   u.mode( x.mode() );
   u.precision( precision );  

   return u;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/24/2005
///	@brief 	Lookup or generate "fixed" constant ln2, PI log10 etc
///	@return 	float_precision	-	return the new table lookup value
///	@param   "tt"	-	Which table type lookup is needed
///	@param    "precision"	-	Number of significant digits
///
///	@todo
///
/// Description:
///   Dynamic tables for "fixed" constant like ln(2), ln(10) and PI
///   If a higher precision is requested we create it and return otherwise 
///   we just the "constant" at a higher precision which eventually will be
///   rounded to the destination variables precision 
//
 static float_precision _float_table( enum table_type tt, unsigned int precision )
   {
   static float_precision ln2( 0, 0, ROUND_NEAR );
   static float_precision ln10( 0, 0, ROUND_NEAR );
   static float_precision pi( 0, 0, ROUND_NEAR );
   float_precision res(0, precision );

   switch( tt )
      {
      case _LN2:
         if( ln2.precision() >= precision )
            res = ln2;
         else
            {
            int j;
            float_precision z2(0, precision + 1 ), u(0, precision + 1), r(0, precision + 1 );
            // Calculate ln2(2)
            ln2.precision( precision );
            ln2 = float_precision( 2 );
            for( j = 1; j <= 2; j++ )
               ln2 = sqrt( ln2 );   // Reduce the number 2 times to get faster taylor iteration
            // Now the number is less than 1.19
            ln2 = ( ln2 - float_precision( 1 ) ) / ( ln2 + float_precision( 1 ) );
            z2 = ln2 * ln2;
            u = ln2;
            // Iterate using taylor series ln(x) == 2( z + z^3/3 + z^5/5 ... )
            for( j=3;;j+=2 )
               {
               u *= z2;
               r = u / float_precision(j);  
               if( ln2 + r == ln2 )
                  break;
               ln2 += r;
               }

            ln2 *= float_precision( 8 ); // 2 * 2^2 == 2^3 == 8
            res = ln2;
            }
         break;
      case _LN10:
         if( ln10.precision() >= precision )
            res = ln10;
         else
            {
            int j;
            float_precision z2(0, precision + 1 ), u(0, precision + 1), r(0, precision + 1 );
            // Calculate ln2(10)
            ln10.precision( precision );
            ln10 = float_precision(10 );
            for( j = 1; j <= 4; j++ )
               ln10 = sqrt( ln10 );   // Reduce the number 4 times to get faster taylor iteration
            // Now the number is less than 1.16
            ln10 = ( ln10 - float_precision( 1 ) ) / ( ln10 + float_precision( 1 ) );
            z2 = ln10 * ln10;
            u = ln10;
            // Iterate using taylor series ln(x) == 2( z + z^3/3 + z^5/5 ... )
            for( j=3;;j+=2 )
               {
               u *= z2;
               r = u / float_precision(j);  
               if( ln10 + r == ln10 )
                  break;
               ln10 += r;
               }

            ln10 *= float_precision( 32 ); // 2 * 2^4 == 2^5 == 32
            res = ln10;
            }
         break;
      case _PI:
         if( pi.precision() > precision )
            res = pi;
         else
            {
            int i;
            float_precision c05( 0.5 ), c1( 1 );
            float_precision x, y, xsq, xsq_inv, r;

            pi.precision( precision + 2 );
            x.precision( precision + 2 );
            y.precision( precision + 2 );
            xsq.precision( precision + 2 );
            xsq_inv.precision( precision + 2 );
            r.precision( precision + 2 );
            // x0 = sqrt(2), pi = 2 + sqrt(2), y = 2^(1/4)
            x = sqrt( float_precision( 2, precision + 2 ) );
            pi = x + float_precision( 2 );
            xsq = sqrt( x );
            xsq_inv = _float_precision_inverse( xsq );
            y = xsq;
            for( i=0;;i++) // Iterate. x = 0.5(sqrt(x)+1/sqrt(x)), pi=pi((x+1)/(y+1)), y=(y*sqrt(x)+1/sqrt(x))/(y+1)
               {
               x = ( xsq + xsq_inv ) * c05;
               r = ( x + c1 ) / ( y + c1 );
               pi *= r;
               xsq = sqrt( x );
               xsq_inv = _float_precision_inverse( xsq );
               y = ( y * xsq + xsq_inv ) / ( y + c1 );
               if( r == c1 )
                  break;
               }
            res = pi;
            // Round to one extra precision and store it
            pi.precision( precision + 1 );  
            }
         break;
      }

   return res;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate exp(x)
///	@return 	   float_precision -	Return exp(x)
///	@param      "x"	-	   The argument
///
///	@todo  
///
/// Description:
///   Use a taylor series until their is no more change in the result
///   exp(x) == 1 + x + x^2/2!+x^3/3!+....
///   Equivalent with the same standard C function call
//
static float_precision exp( const float_precision x )
   {
   unsigned int precision;
   int j, k =0;
   int expo;
   float_precision r, u, v;
   float_precision c05(0.5);

   precision = x.precision() + 1;  
   v.precision( precision );
   v = x;
   r.precision( precision ); // Do iteration using 2 digits higher precision
   u.precision( precision );

   if( v.sign() < 0 )
      v.change_sign();

   for( k = 0; v > c05; )
      {
      expo = v.exponent();
      if( expo > 0 )
         {
         j = 3 * MIN( 10, expo );  // 2^3
         u = _float_precision_inverse( float_precision( 1 << j ) );
         k += j;
         }
      else
         {
         u = c05;
         k++;
         }

      v *= u;
      }

   // Do first two iterations
   u = float_precision(1) + v;
   r = v * v * c05;
   u += r;
   // Now iterate 
   for( j=3;; j++ )
      {
      r *= v / float_precision(j);
      if( u + r == u )
         break;
      u += r;
      }

   for( ; k > 0; k-- )
      u *= u;
   if( x.sign() < 0 )
      u = _float_precision_inverse( u );

   // Round to same precision as argument and rounding mode
   u.mode( x.mode() );
   u.precision( x.precision() );  

   return u;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate log(x)
///	@return 	   float_precision -	Return log(x)
///	@param      "x"	-	   The argument
///
///	@todo  
///
/// Description:
///   Use a taylor series until their is no more change in the result
///   Equivalent with the same standard C function call
///   ln(x) == 2( z + z^3/3 + z^5/5 ...
///   z = (x-1)/(x+1)
//
static float_precision log( const float_precision x )
   {
   unsigned int precision;
   int j, k;
   int expo;
   float_precision res, r, z, z2;

   if( x <= float_precision(0) ) 
      { throw float_precision::domain_error(); return x; }

   precision = x.precision() + 1;  
   z.precision( precision ); // Do calc at one higher precision to allow correct rounding of result
   r.precision( precision ); 
   z2.precision( precision );
   res.precision( precision );
   z = x;
   expo = z.exponent();
   z.exponent( 0 );

   // In order to get a fast Taylor series result we need to get the fraction closer to one
   // The fraction part is [1.xxx-9.999] (base 10) OR [1.xxx-255.xxx] (base 256) at this point
   // Repeat a series of square root until z < 1.2
   for( k = 0; z > float_precision( 1.2 ); k++ )
       z = sqrt(z);

   // Calculate the fraction part now at [1.xxx-1.1999]
   z = ( z - float_precision(1) ) / ( z + float_precision(1) );
   z2 = z * z;
   res = z;
   // Iterate using taylor series ln(x) == 2( z + z^3/3 + z^5/5 ... )
   for( j=3;;j+=2 )
      {
      z *= z2;
      r = z/float_precision(j);
      if( res + r == res )
         break;
      res += r;
      }

   res *= float_precision( pow( 2.0, (double)( k + 1 ) ) );
   if( expo != 0 )
      {
      if( F_RADIX == BASE_10 )  // Ln(x^y) = Ln(x) + Ln(10^y) = Ln(x) + y * ln(10)
         res += float_precision( expo ) * _float_table( _LN10, precision + 1 );
      else     // Ln(x^y) = Ln(x) + Ln(256^y) = Ln(x) + y * ln(256) = Ln(x) + y * ln(2^8) = Ln(x) + y * 8 * ln(2)
         res += float_precision( expo ) * float_precision( 8 ) * _float_table( _LN2, precision + 1 );
      }

   // Round to same precision as argument and rounding mode
   res.mode( x.mode() );
   res.precision( x.precision() );  

   return res;
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate log10(x)
///	@return 	   float_precision -	Return log10(x)
///	@param      "x"	-	   The argument
///
///	@todo  
///
/// Description:
///   Log10. Use the equation log10(x)=log(x)/log(10)
///   Equivalent with the same standard C function call
//
static float_precision log10( const float_precision x )
   {
   unsigned int precision = x.precision();  
   float_precision res( 0, precision + 1 );

   if( x <= float_precision(0) ) 
      { throw float_precision::domain_error(); return x; }

      res = x;
   res = log( res ) / _float_table( _LN10, precision + 1 );
   
   // Round to same precision as argument and rounding mode
   res.mode( x.mode() );
   res.precision( x.precision() );  

   return res;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate pow(x,y)
///	@return 	   float_precision -	Return pow(x,y)
///	@param      "x"	- The argument
///   @param      "y"   - The power argument
///
///	@todo  
///
/// Description:
///   x^y == exp( y * ln( x ) ) );
// 
static float_precision pow( float_precision x, float_precision y )
   {
   float_precision c;

   c.precision( x.precision() );
   c = log( x ) * y;
   c = exp( c );

   return c;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate fmod(x,y)
///	@return 	   float_precision -	Return fmod(x,y)
///	@param      "x"	- The argument
///   @param      "y"   - The argument
///
///	@todo  
///
/// Description:
///   float precision. fmod remainder of x/y
///   Equivalent with the standard C function fmod
///   x = i * y + f or f = x - i * y; and i = integer(x/y)
//
static float_precision fmod( float_precision x, float_precision y )
   {
   float_precision i, f;
   int expo;
   
   f.precision( x.precision() );
   i = x / y;
   expo = i.exponent();
   if( expo < 0 )
      f = x;
   else
      {
      i.mode( ROUND_ZERO);
      i.precision( 1 + expo );
      i.mode( ROUND_NEAR );
      f = x - i * y;
      }

   return f;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate floor(x)
///	@return 	   float_precision -	Return floor(x)
///	@param      "x"	- The argument
///
///	@todo  
///
/// Description:
///   Float Precision floor
///   Equivalent with the same standard C function floor
//
static float_precision floor( float_precision x )
   {
   float_precision f;
   unsigned int precision = 1 + x.exponent();

   if( precision <= 0 ) // is number less than |1|
      {
      if( x.sign() < 0 )
         f = float_precision( -1, x.precision() );
      else
         f = float_precision( 0, x.precision() );
      }
   else
      {
      f.mode( ROUND_DOWN );
      f.precision( precision );
      f = x;
      f.precision( x.precision() );
      f.mode( ROUND_NEAR );
      }
 
   return f;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate ceil(x)
///	@return 	   float_precision -	Return ceil(x)
///	@param      "x"	- The argument
///
///	@todo  
///
/// Description:
///   Float Precision ceil
///   Equivalent with the same standard C function ceil
//
static float_precision ceil( float_precision x )
   {
   float_precision f;
   unsigned int precision = 1 + x.exponent();

   if( precision <= 0 ) // is number less than |1|
      {
      if( x.sign() < 0 )
         f = float_precision( 0, x.precision() );
      else
         f = float_precision( 1, x.precision() );
      }
   else
      {
      f.mode( ROUND_UP );
      f.precision( 1 + x.exponent() );
      f = x;
      f.precision( x.precision() );
      f.mode( ROUND_NEAR );
      }

   return f;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Split a float number into integer part and fraction
///	@return 	   float_precision -	Fraction part of x
///	@param      "x"	- The argument
///   @param      "intptr" - Float_precision pointer to integer part of x
///
///	@todo  
///
/// Description:
///   Float Precision fmod
///   Split a Floating point number into integer part and fraction
///   Equivalent with the same standard C function call
//
static float_precision modf( float_precision x, float_precision *intptr )
   {
   float_precision f(0, x.precision() );
   float_precision c1( 1, x.precision() );

   intptr->precision( x.precision() );

   f = fmod( x, c1 );
   *intptr = x - f;

   return f;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate fabs(x)
///	@return 	   float_precision -	Return absolute value of x
///	@param      "x"	- The argument
///
///	@todo  
///
/// Description:
///   Float Precision fabs
///   Equivalent with the same standard C function call
//
static float_precision fabs( float_precision x )
   {
   float_precision f(0, x.precision() );

   f = x;
   if( f.sign() < 0 )
      f.change_sign();

   return f;
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate ldexp((x)
///	@return 	   float_precision -	Return ldexp(x)
///	@param      "x"	- The argument
///   @param      "exp" - exponent argument
///
///	@todo  
///
/// Description:
///   The ldexp function returns the value of x * 2^exp
//
static float_precision ldexp( float_precision x, int exp )
   {
   if( exp == 0 )
      return x;
   if( exp > 0 && exp <= 31 )
      return x * float_precision( 1 << exp );

   return x * pow( float_precision( 2 ), float_precision( exp ) );
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		Calculate frexp(x,expptr)
///	@return 	   float_precision -	Return mantissa part of number x
///	@param      "x"	- The argument
///   @param      "expptr" - Pointer to the exponent part of number
///
///	@todo  
///
/// Description:
///   The frexp()
///   The frexp function breaks down the floating-point value (x) into a mantissa (m) and an exponent (n), 
///   such that the absolute value of m is greater than or equal to 1/RADIX and less than RADIX, and x = m*Radix^n. 
///   The integer exponent n is stored at the location pointed to by expptr. 
//
static float_precision frexp( float_precision x, int *expptr )
   {
   if( x == float_precision( 0 ) )
      *expptr = 0;

   *expptr = x.exponent();
   x.exponent( 0 );

   return x;
   }


//////////////////////////////////////////////////////////////////////////////////////
///
/// TRIGONOMETRIC FUNCTIONS
///   atan()
///   atan2()
///   asin()
///   acos()
///   sin()
///   cos()
///   tan()
///
//////////////////////////////////////////////////////////////////////////////////////


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		atan
///	@return 		float_precision	-	return atan(x)
///	@param      "x"	-	float_precision argument
///
///	@todo 
///
/// Description:
///   Use the taylot series. ArcTan(x) = x - x^3/3 + x^5/5 ...
///   However first reduce x to abs(x)< 0.5 to improve taylor series
///   using the identity. ArcTan(x)=2*ArcTan(x/(1+sqrt(1+x^2)))
//
static float_precision atan( float_precision x )
   {
   unsigned int precision;
   int j, k;
   float_precision r, u, v, v2;
   float_precision c1(1), c05(0.5);

   precision = x.precision();  
   v.precision( precision );
   v = x;
   r.precision( precision ); 
   u.precision( precision );

   // Transform the solution to ArcTan(x)=2*ArcTan(x/(1+sqrt(1+x^2)))
   k=2;
   v = v / ( c1 + sqrt( c1 + v * v ) );
   if( fabs( v ) > c05 ) // if still to big then do it again
      {
      k=4;
      v = v / ( c1 + sqrt( c1 + v * v ) );
      }

   v2 = v * v;
   r = v;
   u = v;
   // Now iterate using taylor expansion
   for( j=3;; j+=2 )
      {
      v *= v2;
      v.change_sign();
      r = v / float_precision(j);;
      if( u + r == u )
         break;
      u += r;
      }

   u *= float_precision( k );

   // Round to same precision as argument and rounding mode
   u.mode( x.mode() );
   u.precision( precision );  

   return u;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		atan2
///	@return 		float_precision	-	return the angle (in radians) from the X axis to a point (y,x).
///   @param      "y"   -  float_precision y-axis
///	@param      "x"	-	float_precision x-axis
///
///	@todo 
///
/// Description:
///   use atan() to calculate atan2()
//
static float_precision atan2( float_precision y, float_precision x )
   {
   unsigned int precision;
   float_precision u;
   float_precision c0(0), c05(0.5);

   if( x == c0 && y == c0 )
      return c0;

   precision = x.precision();  
   u.precision( precision );
   if( x == c0 )
      {
      u = _float_table( _PI, precision );
      if( y < c0 )
         u *= -c05;
      else
         u *= c05;
      }
   else
      if( y == c0 )
         {
         if( x < c0 )
            u = _float_table( _PI, precision );
         else
            u = c0;
         }
      else
         {
         u = atan( y / x );
         if( x < c0  && y < c0 )
            u -= _float_table( _PI, precision );

         if( x < c0 && y >= c0 )
            u += _float_table( _PI, precision );
         }

// Round to same precision as argument and rounding mode
   u.mode( x.mode() );
   u.precision( precision );  

   return u;
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		asin
///	@return 		float_precision	-	return asin(x)
///	@param      "x"	-	float_precision argument
///
///	@todo 
///
/// Description:
///   Use Newton by solving the equation Sin(y)=x. Then y is Arcsin(x)
///   Iterate by Newton y'=y-(sin(y)-x)/cos(y). With initial guess using 
///   standard double precision arithmetic.
//
static float_precision asin( float_precision x )
   {
   unsigned int precision;
   int j, k, sign;
   double d;
   float_precision r, v, y, f;
   float_precision c1(1), c05(0.5), c2(2);

   if( x > c1 || x < -c1 )
      { throw float_precision::domain_error(); return x; }

   precision = x.precision();  
   y.precision( precision );
   r.precision( precision ); 
   v.precision( precision ); 
   f.precision( precision ); 

   v = x;
   sign = v.sign();
   if( sign < 0 )
      v.change_sign();

   // Reduce the argument to below 0.5 to make the newton run faster
   for( k = 0; v > c05; k++ )
      v /= sqrt( c2 ) * sqrt( c1 + sqrt( c1 - v * v ) );

   d = asin( (double)v );       // Quick estimate 
   y = float_precision( d );
   f = float_precision( 1 / cos( d ) );  // Constant factor 

   // Newton Iteration
   for( j=0;; j++)
      {
      r = ( sin( y ) - v ) * f;
      if( y - r == y )
         break;
      y -=r;
      }
      
   y *= float_precision( 1 << k );

   // Round to same precision as argument and rounding mode
   y.mode( x.mode() );
   y.precision( precision );  

   if( sign < 0 )
      y.change_sign();

   return y;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		acos
///	@return 		float_precision	-	return acos(x)
///	@param      "x"	-	float_precision argument
///
///	@todo 
///
/// Description:
///    Use Arccos(x)=PI/2 - Arcsin(x)
//
static float_precision acos( float_precision x )
   {
   unsigned int precision;
   float_precision y;
   
   precision = x.precision();  
   y = _float_table( _PI, precision );
   y /= float_precision( 2 );
   y -= asin( x );

   // Round to same precision as argument and rounding mode
   y.mode( x.mode() );
   y.precision( precision );  

   return y;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		sin
///	@return 		float_precision	-	return sin(x)
///	@param      "x"	-	float_precision argument
///
///	@todo 
///
/// Description:
///   Use the taylor series. Sin(x) = x - x^3/3! + x^5/5! ...
///   1) However first reduce x to between 0..2*PI 
///   2) Then reduced further to between 0..PI using sin(x+PI)=-Sin(x)
///   3) Finally reduced it to below 0.5 using the trisection identity
///         sin(3x)=3*sin(x)-4*sin(x)^3
///   4) Then do the taylor. 
///   The argument reduction is used to reduced the number of taylor iteration 
///   and to minimize round off erros and calculation time
//
static float_precision sin( float_precision x )
   {
   unsigned int precision;
   int k, j, sign;
   float_precision r, u, v, v2;
   float_precision c05(0.5), c3(3), c4(4);

   precision = x.precision() + 1;  
   v.precision( precision );
   v = x;
   r.precision( precision ); 
   u.precision( precision );
   v2.precision( precision );

   sign = v.sign();
   if( sign < 0 )
      v.change_sign();

   // Reduce argument to between 0..2PI
   u = _float_table( _PI, precision );
   u *= float_precision( 2 );
   if( fabs( v ) > u )
      {
      r = v / u; 
      (void)modf( r, &r ); 
      v -= r * u;
      }
   if( v < float_precision( 0 ) )
      v += u;
      
   // Reduced it further to between 0..PI
   u = _float_table( _PI, precision );
   if( v > u )
      { v -= u; sign *= -1; }

   // Now use the trisection identity sin(3x)=3*sin(x)-4*sin(x)^3
   // until argument is less than 0.5
   for( k = 0, r = float_precision(1); v / r > c05; k++ )
      r *= c3;
   v /= r;

   v2 = v * v;
   r = v;
   u = v;
   // Now iterate using taylor expansion
   for( j=3;; j+=2 )
      {
      v = v2 / ( float_precision(j) * float_precision( j-1) );
      r *= v;
      r.change_sign();
      if( u + r == u )
         break;
      u += r;
      }

   for( ; k > 0 ; k-- )
      u *= ( c3 - c4 * u * u );

   // Round to same precision as argument and rounding mode
   u.mode( x.mode() );
   u.precision( x.precision() );  

   if( sign < 0 )
      u.change_sign();

   return u;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		cos
///	@return 		float_precision	-	return cos(x)
///	@param      "x"	-	float_precision argument
///
///	@todo 
///
/// Description:
///   Use the taylor series. Cos(x) = 1 - x^2/2! + x^4/4! - x^6/6! ...
///   1) However first reduce x to between 0..2*PI
///   2) Then reduced it further to between 0..PI using cos(x)=Cos(2PI-x) for x >= PI
///   3) Now use the trisection identity cos(3x)=-3*cos(x)+4*cos(x)^3
///      until argument is less than 0.5
///   4) Finally use Taylor 
//
static float_precision cos( float_precision x )
   {
   unsigned int precision;
   int k, j;
   float_precision r, u, v, v2;
   float_precision c05(0.5), c1(1), c2(2), c3(3), c4(4);

   precision = x.precision() + 1;  
   v.precision( precision );
   v = x;
   r.precision( precision ); 
   u.precision( precision );
   v2.precision( precision );

   // Reduce argument to between 0..2PI
   u = _float_table( _PI, precision );
   u *= c2;
   if( fabs( v ) > u )
      {
      r = v / u; 
      (void)modf( r, &r ); 
      v -= r * u;
      }
   if( v < float_precision( 0 ) )
      v += u;
      
   // Reduced it further to between 0..PI. u==2PI
   r = _float_table( _PI, precision );
   if( v > r )
      v = u - v;

   // Now use the trisection identity cos(3x)=-3*cos(x)+4*cos(x)^3
   // until argument is less than 0.5
   for( k = 0, r = c1; v / r > c05; k++ )
      r *= c3;
   v /= r;

   v2 = v * v;
   r = c1;
   u = r;
   // Now iterate using taylor expansion
   for( j=2;; j+=2 )
      {
      v = v2 / ( float_precision(j) * float_precision( j-1) );
      r *= v;
      r.change_sign();
      if( u + r == u )
         break;
      u += r;
      }

   for( ; k > 0 ; k-- )
      u *= ( c4 * u * u - c3 );
 
   // Round to same precision as argument and rounding mode
   u.mode( x.mode() );
   u.precision( x.precision() );  

   return u;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 		tan
///	@return 		float_precision	-	return tan(x)
///	@param      "x"	-	float_precision argument
///
///	@todo 
///
/// Description:
///   Use the identity tan(x)=Sin(x)/Sqrt(1-Sin(x)^2)
///   1) However first reduce x to between 0..2*PI
///   2) Use taylot
//
static float_precision tan( float_precision x )
   {
   unsigned int precision;
   float_precision u, r, v, p;
   float_precision c2(2), c3(3);;

   precision = x.precision() + 1;  
   u.precision( precision );
   v.precision( precision );
   p.precision( precision );
   v = x;
  
   // Reduce argument to between 0..2PI
   p = _float_table( _PI, precision );
   u = c2 * p;
   if( fabs( v ) > u )
      {
      r = v / u; 
      (void)modf( r, &r ); 
      v -= r * u;
      }
   
   if( v < float_precision( 0 ) )
      v += u;

   p /= c2;
   if( v == p || v ==  p * c3 )
      { throw float_precision::domain_error(); return x; }

   u = sin( v ); 
   if( v < p || v > p * c3 ) 
      u /= sqrt( float_precision( 1 ) - u * u );
   else
      u /= -sqrt( float_precision( 1 ) - u * u );
   
   // Round to same precision as argument and rounding mode
   u.mode( x.mode() );
   u.precision( x.precision() );  

   return u;
   }


//////////////////////////////////////////////////////////////////////////////////////
///
/// END TRIGONOMETRIC FUNCTIONS
///
//////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////
///
/// CONVERT FLOAT PRECISION to and from ascii representation
///   _float_precision _float_precision_atof()
///   _float_precision_ftoa()
///   _float_precision_dtof()
///
//////////////////////////////////////////////////////////////////////////////////////

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Convert float_precision numbers into string (decimal representation)
///	@return 	std::string - The decimal floating point string	
///	@param   "a"	-	float_precision number to convert
///
///	@todo 	
///
/// Description:
///   Convert float_precision numbers into string (decimal representation)
//
static std::string _float_precision_ftoa( float_precision *a )
   {
   int rem;
   char buf[ 33 ];
   std::string s, src;
   float_precision r256;

   r256.precision( a->precision() );
   r256 = *a;
   s.erase();
   
   if( F_RADIX == BASE_256 )  // 
      {
      float_precision frac, ipart;
      int_precision ip;
      int expo10, expo256;
      bool no_integer;
 
      expo10=0;
      no_integer = false;
      // Convert Integer and fraction part
      frac = modf( r256, &ipart );
      if( ipart == float_precision(0) )
         {
         no_integer = true;
         if( r256.sign() < 0 )
            s = "-0";
         else
            s = "+0";
         }
      else
         {
         std::string::reverse_iterator rpos;
         expo256 = ipart.exponent();
         src = ipart.get_mantissa();
         if( (int)src.length() - 1 <= expo256 )
            src.append( (std::string::size_type)( expo256-src.length()+2 ), (char)0 );
         if( F_RADIX == BASE_10 )
            s = src;
         else
            {
            std::string c0;
            
            c0.insert( (std::string::size_type)0, 1, FCHARACTER( 0 ) );
            s.append( src, 0, 1 );     // Copy sign
            src.erase( src.begin() );  // Erase sign
            for( ; _float_precision_compare( &src, &c0 ) != 0;  )
               {
               src = _float_precision_udiv_short( (unsigned int *)&rem, &src, BASE_10 );
               _float_precision_strip_leading_zeros( &src );
               s.insert( (std::string::size_type)1, 1, (char)FCHARACTER10( rem ) );  
               }
            }
         }
      
      if( frac != float_precision(0) ) 
         {
         std::string::reverse_iterator rpos;
         std::string::iterator pos;
         int count;
         bool leading_zero = true;

         s.append( "." );
         src = frac.get_mantissa(); 
         for( rem = (int)( (log(256)/log(10)*(r256.precision())+1 ) ); rem > 0; )
            {
            frac *= float_precision( 10 );
            frac = modf( frac, &ipart );
            src = ipart.get_mantissa();
            s.append( (std::string::size_type)1, (char)FCHARACTER10( (unsigned char)src[1] % 10 ) );
            if( frac == float_precision( 0 ) )
               break;
            if( leading_zero == true && src[1] % 10 != 0 )
               leading_zero = false;
            if( leading_zero == false )
               rem--;
            }
      
         // Remove trailing zeros
         // Strip trailing zeros
         for( count = 0, rpos = s.rbegin(); rpos != s.rend() && *rpos == '0'; rpos++ )
            count++;
      
         s.erase( s.length() - count, count );
         if( no_integer == true )
            {
            s.erase( 2, 1 );  // Remove the dot
            // Count leading zeros
            for( expo10 = 0, pos = s.begin(), pos++; pos != s.end() && *pos == '0'; pos++ )
               expo10--;
            if( expo10 < 0 )      
               s.erase( 1, -expo10 );        // Remove leading zeros
            if( s.length() > 2 )
               s.insert( 2, "." );           // Insert dot again
            }
         else
            {
            std::string::size_type nidx;
            
            nidx = s.find_first_of( '.' );
            if( nidx > 2 )
               {
               s.erase( nidx, 1 );     // Erase dot
               s.insert( 2, "." );     // and move it to after the first digit
               expo10 += nidx - 2;     // increase the exponent by number os positions moved
               }
            }
         }
      else
         {
         if( no_integer == false )
            {
            if( s.length() > 2 )
               {
               expo10 += s.length() - 2;
               s.insert( (std::string::size_type)2, "." );
               }
            }
         }

      s += "E";
      s += _itoa( expo10, buf, 10 );
      expo256 = 0;
      }
   else
      {
      s = a->get_mantissa();
      if( s.length() > 2 ) 
         s.insert( (std::string::size_type)2, "." );
      s += "E";
      s += _itoa( a->exponent(), buf, 10 );
      }

   return s;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Convert double (IEE754) into a float_precision numbers 
///	@return 	float_precision - The converted float_precision number
///	@param   "d"	- The double IEEE754 number
///   @param   "p"   - The number of significant digits
///   @param   "m"   - Round mode
///
///	@todo 	
///
/// Description:
///   Convert float_precision numbers into string (decimal representation)
//    Constructor for double floating point 
//
//
static float_precision _float_precision_dtof( double d, unsigned int p, enum round_mode m )
   {
   int expo;
   std::string n;
   char buf[ 32 ];
   float_precision fp(0,p,m);
   
   if( d == 0 )
      return fp;
   expo = 0;

   if( F_RADIX == BASE_10 )
      {
      _gcvt( d, 18, buf );
      // sprintf( buf, "%.16e", d );
      fp = _float_precision_atof( buf, p, m );
      }
   else
      {
      int i;
      float_precision cpower2(2);
   
      memcpy( buf, (char *)&d, sizeof( double ) );
      n += "+1"; n[1] = FCHARACTER( 1 );
      n += ( ( buf[ 6 ] & 0xf ) << 4 ) + ( ( buf[ 5 ] & 0xf0 ) >> 4 );
      n += ( ( buf[ 5 ] & 0xf ) << 4 ) + ( ( buf[ 4 ] & 0xf0 ) >> 4 );
      n += ( ( buf[ 4 ] & 0xf ) << 4 ) + ( ( buf[ 3 ] & 0xf0 ) >> 4 );
      n += ( ( buf[ 3 ] & 0xf ) << 4 ) + ( ( buf[ 2 ] & 0xf0 ) >> 4 );
      n += ( ( buf[ 2 ] & 0xf ) << 4 ) + ( ( buf[ 1 ] & 0xf0 ) >> 4 );
      n += ( ( buf[ 1 ] & 0xf ) << 4 ) + ( ( buf[ 0 ] & 0xf0 ) >> 4 );
      _float_precision_strip_trailing_zeros( &n );
      expo = ( ( buf[ 7 ] & 0x7f ) << 4 ) + ( ( buf[ 6 ] & 0xf0 ) >> 4 );
      expo -= 1023;  // unbiased the double exponent
      if( buf[ 7 ] & 0x80 )  // set sign
         n[0] = '-';
      else
         n[0] = '+';
      fp.set_n( n );
      // convert exponent in 2^expo to 256^x. exponent modulo 8 is set straight into expo the remainding 
      // is converted by multiplying repeately with 2 or 0.5
      i = expo % 8;
      expo /= 8;
      fp.exponent( expo );
      if( i > 0 )
         {
         // Create 2^i where i [1..7]
         switch( i )
            {
            case 1: (*cpower2.ref_mantissa())[1] = (char)2; break;
            case 2: (*cpower2.ref_mantissa())[1] = (char)4; break;
            case 3: (*cpower2.ref_mantissa())[1] = (char)8; break;
            case 4: (*cpower2.ref_mantissa())[1] = (char)16; break;
            case 5: (*cpower2.ref_mantissa())[1] = (char)32; break;
            case 6: (*cpower2.ref_mantissa())[1] = (char)64; break;
            case 7: (*cpower2.ref_mantissa())[1] = (char)128; break;
            }
         fp *= cpower2;
         }
      else
         if( i < 0 )
         {
         // std::string s = cpower2.get_mantissa();
         // Create 2^-i where i [-1..-7]
         switch( -i )
            {
            case 1: (*cpower2.ref_mantissa())[1] = (char)0x80; break;
            case 2: (*cpower2.ref_mantissa())[1] = (char)0x40; break;
            case 3: (*cpower2.ref_mantissa())[1] = (char)0x20; break;
            case 4: (*cpower2.ref_mantissa())[1] = (char)0x10; break;
            case 5: (*cpower2.ref_mantissa())[1] = (char)0x8; break;
            case 6: (*cpower2.ref_mantissa())[1] = (char)0x4; break;
            case 7: (*cpower2.ref_mantissa())[1] = (char)0x2; break;
            }
         cpower2.exponent( -1 );
         fp *= cpower2;
         }
      }

   return fp;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Convert a string decimal number into a float_precision number
///	@return 	std::string - The decimal floating point string	
///	@param   "str"	-	ascii string of floating point number to convert
///   @param   "p"   - The precision of the number
///   @param   "m"   - The round mode of the number
///
///	@todo 	
///
/// Description:
///   Convert ascii string into a float_precision numbers 
//    The ascii float format is based on standard C notation
//
static float_precision _float_precision_atof( const char *str, unsigned int p, enum round_mode m )
   {
   int sign, sign_expo;
   int expo, expo_radix, expo_e;
   int s_digit, f_digit;
   std::string::size_type nidx, idx;
   int i;
   std::string s(str);
   std::string::iterator pos;
   std::string number, fraction, exponent;
   float_precision fp(0,p,m);

   expo = 0;
   idx=0;
   sign = CHAR_SIGN( '+' );
   // Parse leading sign if any
   pos = s.begin();
   if( *pos == '+' || *pos == '-' )  // 
      {
      sign = CHAR_SIGN( *pos );
      pos++;
      idx=1;
      if( pos == s.end() )
         { throw float_precision::bad_int_syntax(); return fp; }
      }

   // Determine any significant, fraction sign or exponent sign
   nidx = s.find_first_of( ".eE", idx );
   if( nidx == std::string::npos ) // Only digits (INTEGER) if any
      {
      if( *pos == '0' ) // Octal or hex representation
         {
         if( pos+1 != s.end() && tolower( pos[1] ) == 'x' )
            {
            for( pos += 2; pos != s.end(); pos++ )
               if( ( *pos < '0' || *pos > '9' ) && ( tolower( *pos ) < 'a' || tolower( *pos ) > 'f' ) )
                  {  throw float_precision::bad_int_syntax(); return fp; }
               else
                  {
                  char buf[ 16 ];
                  std::string tmp;

                  int hexvalue = *pos - '0';
                  if( hexvalue > 10 )
                     hexvalue = tolower( *pos ) - 'a' + 10;
                  itoa( BASE_16, &buf[ 0 ], BASE_10 );
                  tmp = buf;
                  number = _float_precision_umul_fourier( &number, &tmp );

                  itoa( hexvalue, &buf[ 0 ], BASE_10 );
                  tmp = buf;
                  number = _float_precision_uadd( &number, &tmp );
                  }
            }
         else
            { // Collect octal represenation
            for( ; pos != s.end(); pos++ )
               if( *pos < '0' || *pos > '7' )
                  { throw float_precision::bad_int_syntax(); return fp; }
               else
                  {
                  number = _float_precision_umul_short( &number, BASE_8 );
                  number = _float_precision_uadd_short( &number, *pos - '0' );
                  }
            }
         }
      else
         { // Collect decimal representation
         for( ; pos != s.end(); pos++ )
            if( *pos < '0' || *pos > '9' )
               {  throw float_precision::bad_int_syntax(); return fp; }
            else
               {
               number = _float_precision_umul_short( &number, BASE_10 );
               number = _float_precision_uadd_short( &number, *pos - '0' );
               }
         }

      // This is all integers digits, so exponent is the number of digits
      _float_precision_strip_leading_zeros( &number ); // First strip for leading zeros
      expo = number.length() -1;                       // Always one digit before the dot
      _float_precision_strip_trailing_zeros( &number ); // Get rid of trailing non-significant zeros
      expo += _float_precision_rounding( &number, sign, p, m );
      number.insert( (std::string::size_type)0, SIGN_STRING( sign ) ); // Build the complete number
      fp.set_n( number );
      fp.exponent( expo );

      return fp;
      }

   s_digit = 0;
   f_digit = 0;
   // Pick up significant beteen idx and nidx 
   if( nidx > idx ) // Number of digits before the . sign or exponent
      {
      // Strip leading zeros
      for( i = idx; i != nidx; i++ ) if( s[i] != '0' ) break;
      // Collect significant
      for( ; i != nidx; i++ )
            if( s[i] < '0' || s[i] > '9' )
               {  throw float_precision::bad_float_syntax(); return float_precision(0); }
            else
               {
               number = _float_precision_umul_short( &number, BASE_10 );
               number = _float_precision_uadd_short( &number, s[i] - '0' );
               s_digit++;  // Significant digits. leading space are not counted
               }
      }

   // Floating point representation
   if( s[ nidx ] == '.' ) // Any fraction ?
      { 
      idx = nidx + 1;                      // Find start of fraction
      nidx = s.find_first_of( "eE", idx ); // Find end of fraction
      if( nidx == std::string::npos )
         nidx = s.length();

      // Remove trailing zero digits
      for( i = nidx - 1; i >= idx; i--, nidx-- ) if( s[i] != '0' ) break;
      for( i = idx; i < nidx; i++ )
          if( s[i] < '0' || s[i] > '9' )
             {  throw float_precision::bad_float_syntax(); return float_precision(0); }
            else
               {
               number = _float_precision_umul_short( &number, BASE_10 );
               number = _float_precision_uadd_short( &number, s[i] - '0' );
               f_digit++; // fraction digits. trailing zeros are not counted
               }

      nidx = s.find_first_of( "eE", idx );
      }

   expo_e = 0;
   if( nidx != std::string::npos && ( s[ nidx ] == 'e' || s[ nidx ] == 'E' ) )
      {// Parse the exponent 
      idx = nidx + 1;
      nidx = s.length();
      sign_expo = CHAR_SIGN( '+' );;
      if( idx < nidx && ( s[idx] == '+' || s[idx] == '-' ) )  
         {
         sign_expo = CHAR_SIGN( s[idx] );
         idx++;
         if( idx == nidx )
            { throw float_precision::bad_float_syntax(); return float_precision(0); }  // Sign but no number
         }
      else
         if( idx >= nidx )
            { throw float_precision::bad_float_syntax(); return float_precision(0); }  // E but no number
         
      // Collect exponent using base 10
      for( i = idx; i < nidx; i++ )
          if( s[i] < '0' || s[i] > '9' )
             {  throw float_precision::bad_float_syntax(); return float_precision(0); }
          else
             {
             expo_e *= BASE_10;
             expo_e += s[i] - '0';
             }
      if( sign_expo < 0 )
         expo_e= -expo_e;

      //
      if( number.length() == 0 )
         {
         number += "1";
         }
      }

   expo_radix = number.length() - 1;  // Always one digit before the dot
   if( f_digit > 0 )
      expo_e += -f_digit;  // Adjust for fraction counted as a significant
         
   if( F_RADIX == BASE_10 )
      expo_radix += expo_e;

   // Put it all together
   // Now the number has everything so get rid of trailing non-significant zeros
   expo_radix += _float_precision_normalize( &number );                // Normalize
   expo = _float_precision_rounding( &number, sign, p, m );    // Perform rounding
   expo += expo_radix;
   number.insert( (std::string::size_type)0, SIGN_STRING( sign ) ); // Build the complete number
   fp.set_n( number );
   fp.exponent( expo_radix );

   if( F_RADIX == BASE_256 && expo_e != 0 )
      {
      if( expo_e > 0 )
         {
         float_precision cpower100(100, p, m ), cpower10(10, p, m );
      
         for( ; expo_e >= 2; expo_e -= 2 )
            fp *= cpower100;
         for( ; expo_e >= 1; expo_e-- )
            fp *= cpower10;
         }
      else
         if( expo_e < 0 )
            {
            float_precision cpower01(10, p+1, m ), cpower001(100, p+1, m );

            cpower01 = _float_precision_inverse( cpower01 );   // Hand craf it to the correct precision
            cpower001 = _float_precision_inverse( cpower001 ); // Hand craf it to the correct precision

            for( ; expo_e < -1; expo_e += 2 )
               fp *= cpower001;
            for( ; expo_e < 0; expo_e++ )
               fp *= cpower01;
            }
      }

   return fp;
   }


//////////////////////////////////////////////////////////////////////////////////////
///
/// END CONVERT FLOAT PRECISION to and from ascii representation
///
//////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////
///
/// FLOATING POINT CORE FUNCTIONS
///
///   _float_precision_strip_leading_zeros
///   _float_precision_strip_trailing_zeros
///   _float_precision_normalize
///   _float_precision_rounding
///   _float_precision_right_shift
///   _float_precision_left_shift
///   _float_precision_compare
///   _float_precision_uadd_short
///   _float_precision_uadd
///   _float_precision_usub_short
///   _float_precision_usub
///   _float_precision_umul_short
///   _float_precision_umul
///   _float_precision_umul_fourier
///   _float_precision_udiv_short
///
///   Works Directly on the string class of the float number
///
//////////////////////////////////////////////////////////////////////////////////////


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Remove leading nosignificant zeros from the string
///	@return 	nothing	
///	@param   "s"	-	digital string
///
///	@todo  
///
/// Description:
///   Remove leading nosignificant zeros
//
static void _float_precision_strip_leading_zeros( std::string *s )
   {
   std::string::iterator pos;

   // Strip leading zeros
   for( pos = s->begin(); pos != s->end() && FDIGIT( *pos ) == 0; )
         s->erase( pos );
      
   if( s->length() == 0 )
      *s = FCHARACTER(0);

   return;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Remove trailingnosignificant zeros from the string
///	@return 	nothing	
///	@param   "s"	-	digital string
///
///	@todo  
///
/// Description:
///   Remove trailing nosignificant zeros
//
static void _float_precision_strip_trailing_zeros( std::string *s )
   {
   std::string::reverse_iterator pos;
   int count;

   // Strip trailing zeros
   for( count = 0, pos = s->rbegin(); pos != s->rend() && FDIGIT( *pos ) == 0; pos++ )
         count++;
      
   s->erase( s->length() - count, count );
   if( s->length() == 0 )
      *s = FCHARACTER(0);

   return;
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Right shift a string number 
///	@return 	nothing	
///	@param   "s"	-	digital string
///   @param   "shift" - Number of digital shifts
///
///	@todo  
///
/// Description:
///   Right shift number x decimals by inserting 0 in front of the number
//
static void _float_precision_right_shift( std::string *s, int shift )
   {
   s->insert( (std::string::size_type)0, shift, FCHARACTER( 0 ) );
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Left shift a string number 
///	@return 	nothing	
///	@param   "s"	-	digital string
///   @param   "shift" - Number of digital shifts
///
///	@todo  
///
/// Description:
///   Left shift number x decimals by appending 0 in the back of the number
//
static void _float_precision_left_shift( std::string *s, int shift )
   {
   s->append( shift, FCHARACTER( 0 ) );
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Normalize a floating point mantissa
///	@return 	int - Return the exponent adjustment factor due to normalization
///	@param   "m"	-	digital string
///
///	@todo  
///
/// Description:
///   Normalize the mantissa
///   1) If a number does not have a leading digit != 0 then left shift until 
///   it has and adjust the exponent accordingly and return it.
///   2) Then remove trailing zeros
///   3) The mantissa NEVER contain a leading sign
//
static int _float_precision_normalize( std::string *m )
   {
   int expo = 0;
   std::string::iterator pos;

   // Left shift until a digit is not 0
   for( pos = m->begin(); pos != m->end() && FDIGIT( *pos ) == 0; )
      {
      m->erase( pos );
      expo--;
      }
      
   if( m->length() == 0 ) // If all zero the number is zero
      {
      *m = FCHARACTER(0);
      return 0;
      }

   _float_precision_strip_trailing_zeros( m );

   return expo;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Round the mantisaa to significant digits and rounding control
///	@return 	int - Return the exponent adjustment (0 or 1) 
///	@param   "m"	-	digital string
///   @param   "sign"   - The sign of the number
///   @param   "precision" - The digital precision
///   @param   "mode"   - Rounding mode 
///
///	@todo  
///
/// Description:
///   Rounding control
///   Round the fraction to the number of precision based on the round mode 
///   Note that the mantissa number has ALWAYS been normalize prior to rounding
///   The mantissa NEVER contain a leading sign
///   Rounding Mode Positive numnber   Result    
///   Rounding to nearest              +�   
///   Rounding toward zero (Truncate)  Maximum, positive finite value   
///   Rounding up (toward +�)          +�   
///   Rounding down) (toward -�)       Maximum, positive finite value   
///
///   Rounding Mode Negative number    Result    
///   Rounding to nearest              -�   
///   Rounding toward zero (Truncate)  Maximum, negative finite value   
///   Rounding up (toward +�)          Maximum, negative finite value   
///   Rounding down) (toward -�)       -�   
//
int _float_precision_rounding( std::string *m, int sign, unsigned int precision, enum round_mode mode )
   {
   enum round_mode rm = mode;

   if( m->length() > precision )  // More digits than we need 
      {
      if( rm == ROUND_NEAR )
         {
         if( 2 * FDIGIT( (*m)[ precision ] ) >= F_RADIX )
            rm = ROUND_UP; //sign < 0 ? ROUND_DOWN : ROUND_UP;
         else
            rm = ROUND_DOWN; // sign < 0 ? ROUND_UP : ROUND_DOWN;
         }
      else
         if( rm == ROUND_UP && sign < 0 )
            rm = ROUND_DOWN;
         else
            if( rm == ROUND_DOWN && sign < 0 )
               rm = ROUND_UP;

      // Chuck excessive digits
      m->erase( (std::string::size_type)precision, m->length() - precision );

      if( rm == ROUND_UP ) 
         {
         int before;

         before = m->length();
         *m = _float_precision_uadd_short( m, 1 );
         if( m->length() > before )
            {
            if( m->length() > precision )
               m->erase( (std::string::size_type)precision, m->length() - precision );

            _float_precision_strip_trailing_zeros( m );            
            return 1;
            }
         }
      }

   _float_precision_strip_trailing_zeros( m );            

   return 0;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	Compare to floating point string (mantissa on;y)
///	@return 	int - Return the compared result. 0==same, 1==s1>s2 or -1==s1<s2
///	@param   "s1"	-	First digital string
///   @param   "s2"  - Second digital string
///
///	@todo  
///
/// Description:
///   Compare two unsigned decimal string 
///   and return 0 is equal, 1 if s1 > s2 otherwise -1
///   Optimized check length first and determine 1 or -1 if equal
///   compare the strings
//
static int _float_precision_compare( std::string *s1, std::string *s2 )
   {
   int cmp;

   if( s1->length() > s2->length() )
      cmp = 1;
   else
      if( s1->length() < s2->length() )
         cmp = -1;
      else
         cmp = s1->compare( *s2 );

   return cmp;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	add a short integer to a floating point string (mantissa)
///	@return 	std::string - Return the added string
///	@param   "src1"	-	The source string
///   @param   "d"  - The number to add
///
///	@todo  
///
/// Description:
///   Short float Add: The digit d [0..F_RADIX] is added to the unsigned fraction string
///   Optimized 0 add or early out add is implemented
//
static std::string _float_precision_uadd_short( std::string *src1, unsigned int d )
   {
   unsigned short ireg;
   std::string::reverse_iterator r1_pos, rd_pos;
   std::string des1;

   if( d > F_RADIX )
      {
      throw float_precision::out_of_range();
      des1.insert( (std::string::size_type)0, 1, FCHARACTER(0) );
      return des1;
      }

   if( d == 0 )   // Zero add
      return *src1;

   ireg = F_RADIX * d;
   des1 = *src1;
   rd_pos = des1.rbegin();
   r1_pos = src1->rbegin();
   
   for(; r1_pos != src1->rend(); r1_pos++, rd_pos++ )
      {
      ireg = FDIGIT( *r1_pos ) + FCARRY( ireg ); 
      *rd_pos = FCHARACTER( FSINGLE( ireg ) );
      if( FCARRY( ireg ) == 0 ) // Early out add
         break;
      }

   if( FCARRY( ireg ) != 0 )  // Insert the carry in the front of the number
      des1.insert( (std::string::size_type)0, 1, FCHARACTER( FCARRY( ireg ) ) );

   return des1;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	add two floating point string
///	@return 	std::string - Return the added string
///	@param   "src1"	-	The first source string
///   @param   "src2"  - The second source string
///
///	@todo  
///
/// Description:
///   Add two unsigned decimal strings
///   Optimized: Used early out add
//
static std::string _float_precision_uadd( std::string *src1, std::string *src2 )
   {
   unsigned short ireg = 0;
   std::string des1;
   std::string::reverse_iterator r_pos, r_end, rd_pos;

   if( src1->length() >= src2->length() )
      {
      des1 = *src1; 
      r_pos = src2->rbegin();
      r_end = src2->rend();
      }
   else
      {
      des1 = *src2;
      r_pos = src1->rbegin();
      r_end = src1->rend();
      }
   rd_pos = des1.rbegin();
   
   for(; r_pos != r_end;)
      { // Adding element by element for the two numbers
      ireg = FDIGIT( *r_pos ) + FDIGIT( *rd_pos ) + FCARRY( ireg );
      *rd_pos = FCHARACTER( FSINGLE( ireg ) );
      r_pos++;
      rd_pos++;
      }

   // Exhaust the smalles of the number, so only the carry can changes the uppper radix digits
   for( ; FCARRY( ireg ) != 0 && rd_pos != des1.rend(); )
      {
      ireg = FDIGIT( *rd_pos ) + FCARRY( ireg );
      *rd_pos = FCHARACTER( FSINGLE( ireg ) );
      rd_pos++;
      }

   // No more carry or end of upper radix number. 
   if( FCARRY( ireg ) != 0 ) // If carry add the carry as a extra radix digit to the front of the number
      des1.insert( (std::string::size_type)0, 1, FCHARACTER( FCARRY( ireg ) ) );

   return des1;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	subtract a short integer from a floating point string (mantissa)
///	@return 	std::string - Return the subtracted string
///   @param   "result" -  If the number wraps around (d > src1 ) then result=1 otherwise 0
///	@param   "src1"	-	The source string
///   @param   "d"  - The number to subtract
///
///	@todo  
///
/// Description:
///   Short Subtract: The digit d [0..F_RADIX] is subtracted from a unsigned decimal string
///   if src1 < src2 return -1 (wrap around) otherwise return 0 (no wrap around)
//
static std::string _float_precision_usub_short( int *result, std::string *src1, unsigned int d )
   {
   unsigned short ireg = RADIX;
   std::string::reverse_iterator r1_pos;
   std::string::iterator d_pos;
   std::string des1;

   if( d > F_RADIX )
      {
      throw float_precision::out_of_range();
      des1.insert( (std::string::size_type)0, 1, FCHARACTER(0) );
      return des1;
      }

   if( d == 0 ) // Nothing to subtract
      {
      *result = 0;
      return *src1;
      }

   des1.erase();
   d_pos = des1.begin();
   r1_pos = src1->rbegin();

   ireg = F_RADIX - 1 + FDIGIT( *r1_pos ) - d + FCARRY( ireg );
   d_pos = des1.insert( d_pos, FCHARACTER( FSINGLE( ireg ) ) );
   for( r1_pos++; FCARRY( ireg ) && r1_pos != src1->rend(); r1_pos++ )
      {
      ireg = F_RADIX - 1 + FDIGIT( *r1_pos ) + FCARRY( ireg );
      d_pos = des1.insert( d_pos, FCHARACTER( FSINGLE( ireg ) ) );
      }

   *result = FCARRY( ireg ) - 1;
   return des1;
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	subtract two floating point string
///	@return 	std::string - Return the subtracted string
///   @param   "result" -  If the number wraps around (d > src1 ) then result=1 otherwise 0
///	@param   "src1"	-	The first source string
///   @param   "src2"  - The second source string
///
///	@todo  
///
/// Description:
///   Subtract two unsigned decimal strings
///   if src1 < src2 return -1 (wrap around) otherwise return 0 (no wrap around)
//
static std::string _float_precision_usub( int *result, std::string *src1, std::string *src2 )
   {
   unsigned short ireg = F_RADIX;
   std::string::reverse_iterator r1_pos, r2_pos;
   std::string::iterator d_pos;
   std::string des1;

   des1.erase();
   d_pos = des1.begin();
   r1_pos = src1->rbegin();
   r2_pos = src2->rbegin();

   for(; r1_pos != src1->rend() || r2_pos != src2->rend();)
      {
      if( r1_pos != src1->rend() && r2_pos != src2->rend() )
         { ireg = F_RADIX - 1 + FDIGIT( *r1_pos ) - FDIGIT( *r2_pos ) + FCARRY( ireg ); r1_pos++, r2_pos++; }
      else
         if( r1_pos != src1->rend() )
            { ireg = F_RADIX - 1 + FDIGIT( *r1_pos ) + FCARRY( ireg ); r1_pos++; }
         else
            { ireg = F_RADIX - 1 - FDIGIT( *r2_pos ) + FCARRY( ireg ); r2_pos++; }
      d_pos = des1.insert( d_pos, FCHARACTER( FSINGLE( ireg ) ) );
      }

   *result = FCARRY( ireg ) - 1;
   return des1;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	multiply a short integer to a floating point string (mantissa)
///	@return 	std::string - Return the multiplied string
///	@param   "src1"	-	The source string
///   @param   "d"  - The number to multiply
///
///	@todo  
///
/// Description:
///   Short float Multiplication: The unsigned digit d [0..F_RADIX] is multiplied to the unsigned fraction 
///   Optimize: Multiply with zero yields zero;
//
static std::string _float_precision_umul_short( std::string *src1, unsigned int d )
   {
   unsigned short ireg = 0;
   std::string::reverse_iterator r1_pos;
   std::string::iterator d_pos;
   std::string des1;

   if( d > F_RADIX )
      {
      throw float_precision::out_of_range();
      des1.insert( (std::string::size_type)0, 1, ( FCHARACTER(0) ) );
      return des1;
      }

   if( d == 0 )
      {
      des1.insert( (std::string::size_type)0, 1, ( FCHARACTER(0) ) );
      return des1;
      }

   if( d == 1 )
      {
      des1 = *src1;
      return des1;
      }

   if( d == F_RADIX )  
      {
      des1.insert( (std::string::size_type)0, 1, ( FCHARACTER(0) ) );
      des1 = *src1 + des1;
      _float_precision_strip_leading_zeros( &des1 );
      return des1;
      }

   des1.erase();             
   d_pos = des1.begin();
   r1_pos = src1->rbegin();
   
   for( ; r1_pos != src1->rend(); r1_pos++ )
      {
      ireg = FDIGIT(  *r1_pos ) * d + FCARRY( ireg );
      d_pos = des1.insert( d_pos, FCHARACTER( FSINGLE( ireg ) ) );
      }

   if( FCARRY( ireg ) != 0 )
      d_pos = des1.insert( d_pos, FCHARACTER( FCARRY( ireg ) ) );

   return des1;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	multiply two floating point string
///	@return 	std::string - Return the multiplied string
///	@param   "src1"	-	The first source string
///   @param   "src2"  - The second source string
///
///	@todo  
///
/// Description:
///   Multiply two unsigned decimal strings
///   Optimized: Used early out add and multiplication w. zero
///   NO LONGER IN USE. Replaced by _float_precision_umul_fourier
//
static std::string _float_precision_umul( std::string *src1, std::string *src2 )
   {
   unsigned short ireg = 0;
   int disp;
   std::string des1, tmp;
   std::string::reverse_iterator r_pos2;
   
   r_pos2 = src2->rbegin();
   des1 = _float_precision_umul_short( src1, FDIGIT( *r_pos2 ) );
   for( r_pos2++, disp = 1; r_pos2 != src2->rend(); disp++, r_pos2++ )
      {
      if( FDIGIT( *r_pos2 ) != 0 )
         {
         tmp = _float_precision_umul_short( src1, FDIGIT( *r_pos2 ) );
         tmp.append( disp, FCHARACTER( 0 ) );
         des1 = _float_precision_uadd( &des1, &tmp );
         }
      }

   _float_precision_strip_leading_zeros( &des1 ); 

   return des1;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	multiply two floating point string unsing a fourie transformation
///	@return 	std::string - Return the multiplied string
///	@param   "src1"	-	The first source string
///   @param   "src2"  - The second source string
///
///	@todo  
///
/// Description:
///   Multiply two unsigned decimal strings
///   Optimized: Used early out add and multiplication w. zero
///   This is considerable faster than the previous methode and is used now
//
static std::string _float_precision_umul_fourier( std::string *src1, std::string *src2 )
   {
   unsigned short ireg = 0;
   std::string des1;
   std::string::iterator pos;
   unsigned int n, l, l1, l2;
   int j;
   double *a, *b, cy;
   
   l1 = src1->length();
   l2 = src2->length();
   l = l1 < l2 ? l2 : l1;
   for( n = 1; n < l; n <<= 1 ) ;
   n <<= 1;
   a = new double [n];
   b = new double [n];
   for( l=0, pos = src1->begin(); pos != src1->end(); pos++ ) a[l++] = (double)FDIGIT(*pos);
   for( ; l < n; ) a[l++] = (double)0;
   for( l=0, pos = src2->begin(); pos != src2->end(); pos++ ) b[l++] = (double)FDIGIT(*pos);
   for( ; l < n; ) b[l++] = (double)0;
   _int_real_fourier( a, n, 1 );
   _int_real_fourier( b, n, 1 );
   b[0] *= a[0];
   b[1] *= a[1];
   for( j = 2; j < n; j += 2 )
      {
      double t;
      b[j]=(t=b[j])*a[j]-b[j+1]*a[j+1];
      b[j+1]=t*a[j+1]+b[j+1]*a[j];
      }
   _int_real_fourier( b, n, -1 );
   for( cy=0, j=n-1; j >= 0; j-- )
      {
      double t;
      t=b[j]/(n>>1)+cy+0.5;
      cy=(unsigned long)( t/ F_RADIX );
      b[j]=t-cy*F_RADIX;
      }

   ireg = cy;
   if( ireg != 0 )
      des1.append( 1, FCHARACTER( ireg ) );
   for( j = 0; j < l1 + l2 -1; j++ )
      des1.append( 1, FCHARACTER( b[ j ] ) );
   
   _float_precision_strip_leading_zeros( &des1 );
   delete [] a;
   delete [] b;

   return des1;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/21/2005
///	@brief 	divide a short integer into a floating point string (mantissa)
///	@return 	std::string - Return the divided floating point string
///   @param   "remaind" -  Any remainding portion of the division
///	@param   "src1"	-	The source string
///   @param   "d"  - The number to divide
///
///	@todo  
///
/// Description:
///   Short Division: The digit d [1..F_RADIX] is divide up into the unsigned decimal string
//
static std::string _float_precision_udiv_short( unsigned int *remaind, std::string *src1, unsigned int d )
   {
   int i, ir;
   std::string::iterator s1_pos;
   std::string des1;
   
   if( d > F_RADIX )
      {
      throw float_precision::out_of_range();
      des1.insert( (std::string::size_type)0, 1, FCHARACTER(0) );
      return des1;
      }

   if( d == 0 )
      {
      throw float_precision::divide_by_zero();
      des1.insert( (std::string::size_type)0, 1, FCHARACTER(0) );
      return des1;
      }

   des1.erase();
   s1_pos = src1->begin();
   
   ir = 0;
   for(; s1_pos != src1->end(); s1_pos++ )
      {
      i = F_RADIX * ir + FDIGIT( *s1_pos );
      des1 += FCHARACTER( (unsigned char)( i / d ) );
      ir = i % d;
      }

   *remaind = ir;
   return des1;
   }


//////////////////////////////////////////////////////////////////////////////////////
///
/// END FLOATING POINT CORE FUNCTIONS
///
///
//////////////////////////////////////////////////////////////////////////////////////


#endif