#ifndef INC_INTERVAL
#define INC_INTERVAL

/*
 *******************************************************************************
 *
 *
 *                       Copyright (c) 2002-2003
 *                       Future Team Aps 
 *                       Denmark
 *
 *                       All Rights Reserved
 *
 *   This source file is subject to the terms and conditions of the
 *   Future Team Software License Agreement which restricts the manner
 *   in which it may be used.
 *   Mail: hve@hvks.com
 *
 *******************************************************************************
*/

/*
 *******************************************************************************
 *
 *
 * Module name     :   intervalprecision.h
 * Module ID Nbr   :   
 * Description     :   Interval Precision arithmetic template class
 *                     Works with the int_precision and float_precision classes
 * --------------------------------------------------------------------------
 * Change Record   :   
 *
 * Version	Author/Date		Description of changes
 * -------  -----------		----------------------
 * 01.01		HVE/020209		Initial release
 * 01.02    HVE/030421     Optimized the * operator to reduce the 8 multiplications
 *                         to 2.
 *
 * End of Change Record
 * --------------------------------------------------------------------------
*/


/* define version string */
static char _VinterP_[] = "@(#)intervalprecision.h 01.02 -- Copyright (C) Future Team Aps";

#include <float.h>

// 
// Interval class
// Realisticly the class Type can be float, double, int_precision, & float_precision
// Since float and double are done unsing the Intel cpu (H/W) and using "specilization" 
// the int_precision and float_precision is done using the arbitrary precision packages
// Since their is no way to specific portable ROUND_DOWN and ROUND_UP mode the template class 
// heavily use specilization. For any other type besides float, double, int_precision and float_precision
// the operations is not defined
//
template<class IT> class interval {
   IT low, high;
   public:
      typedef IT value_type;

      // constructor
      interval( const IT& l, const IT& h) { if( l < h ) { low =l; high = h; } else { low = h; high = l; } }
      interval( const IT& d = IT(0) ) : low(d), high(d) {}
      // constructor for any other type to IT
      template<class X> interval( const interval<X>& a ) : low(a.lower()), high( a.upper())  { if( a.lower() < a.upper() ) { low =(IT)a.lower(); high = (IT)a.upper(); } else { low = (IT)a.upper(); high = (IT)a.lower(); } }
      
      // Coordinate functions
      IT upper() const        { return high; }
      IT lower() const        { return low; }
      IT upper( const IT& u ) { return ( high = u ); }
      IT lower( const IT& l ) { return ( low = l ); }

      IT center() const { return ( high + low ) / (IT)2; }
      IT radius() const { IT r; r =( high - low ) / (IT)2; if( r < (IT)0 ) r = -r; return r; }
      operator double() const { return (double)( ( high + low ) / (IT)2 ); }  // Conversion to Double 
      operator int() const { return (int)( ( high + low ) / (IT)2 ); }  // Conversion to int 
      IT *ref_lower()   { return &low; }
      IT *ref_upper()   { return &high; }

      // Essential operators
      interval<IT>& operator= ( const interval<IT>& );
      interval<IT>& operator+=( const interval<IT>& );
      interval<IT>& operator-=( const interval<IT>& );
      interval<IT>& operator*=( const interval<IT>& );
      interval<IT>& operator/=( const interval<IT>& );
   };


interval<class IT> operator+( const interval<class IT>&, const interval<class IT>& );
interval<class IT> operator+( const interval<class IT>& );  // Unary 
interval<class IT> operator-( const interval<class IT>&, const interval<class IT>& );
interval<class IT> operator-( const interval<class IT>& );                 // Unary
interval<class IT> operator*( const interval<class IT>&, const interval<class IT>& );
interval<class IT> operator/( const interval<class IT>&, const interval<class IT>& );

interval<double> log( const interval<double>& );
interval<double> log10( const interval<double>& );
interval<double> sqrt( const interval<double>& );
interval<double> pow( const interval<double>&, const double );
interval<double> exp( const interval<double>& );

// Output Operator <<
//
template<class _Ty> ostream& operator<<( ostream& strm, interval<_Ty>& a ) { return strm << "[" << a.lower() << "," << a.upper() << "]"; }

// Input operator >>
//
template<class _Ty> istream& operator>>( istream& strm, interval<_Ty>& c ) 
   {
   _Ty l, u; char ch;
   if( strm >> ch && ch != '[')
      strm.putback(ch), strm >> l, h = (_Ty)0;
	else
      if( strm >> h >> ch && ch != ',')
	      if( ch == ']')
	         h = (_Ty)0;
	      else 
            strm.putback( ch ); // strm.setstate(std::ios::failbit);
	   else
         if( strm >> im >> ch && ch != ']')
	         strm.putback( ch ); //, strm.setstate(ios_base::failbit);
	
   if(!strm.fail())
	   c = interval<_Ty>( l, h );

   return strm;
   }

// Works for all class types
//
template<class IT> interval<IT>& interval<IT>::operator=( const interval<IT>& a )
   {
   low = a.lower();
   high = a.upper();

   return *this;
   }


// Works all other classes. 
// Please note that for interval<int>, interval<long>, interval<int_precision>
// we just have some unecessary calls to controlfp()
//
template<class IT> interval<IT>& interval<IT>::operator+=( const interval<IT>& a )
   {
   _controlfp( _RC_DOWN, _MCW_RC );
   low += a.lower();
   
   _controlfp( _RC_UP, _MCW_RC );
   high += a.upper();
   
   _controlfp( _RC_NEAR, _MCW_RC );

   return *this;
   }


// Specilization for float_precision and +=
//
interval<float_precision>& interval<float_precision>::operator+=( const interval<float_precision>& a )
   {
   low.mode( ROUND_DOWN );
   low += a.lower();
   
   high.mode( ROUND_UP );
   high += a.upper();
   
   return *this;
   }

// Works all other classes. 
// Please note that for interval<int>, interval<long>, interval<int_precision>
// we just have some unecessary calls to controlfp()
//
template<class IT> interval<IT>& interval<IT>::operator-=( const interval<IT>& a )
   {
   _controlfp( _RC_DOWN, _MCW_RC );
   low -= a.high;

   _controlfp( _RC_UP, _MCW_RC );
   high -= a.low;
   
   _controlfp( _RC_NEAR, _MCW_RC );

   return *this;
   }

// Specilization for float_precision and -=
//
interval<float_precision>& interval<float_precision>::operator-=( const interval<float_precision>& a )
   {
   low.mode( ROUND_DOWN );
   low -= a.lower();
   
   high.mode( ROUND_UP );
   high -= a.upper();
   
   return *this;
   }

// Works all other classes. 
// Please note that for interval<int>, interval<long>, interval<int_precision>
// we just have some unecessary calls to controlfp()
// Instead of doing the mindless low = MIN(low*a.high, low*a.low,high*a.low,high*a.high) and
// high = MAX(low*a.high, low*a.low,high*a.low,high*a.high) requiring a total of 8 multiplication
//
//   low, high, a.low, a.high    result
//    +     +     +     +        +  +  [ low*a.low, high*a.high ]
//    +     +     -     +        -  +  [ high*a.low, high*a.high ]
//    +     +     -     -        -  -  [ high*a.low, low*a.high ]
//    -     +     +     +        -  +  [ low*a.high, high*a.high ]  
//    -     +     -     +        -  +  [ MIN(low*a.high,high*a.low), MAX(low*a.low,high*a.high) ]
//    -     +     -     -        -  -  [ high*a.low, low*a.low ]
//    -     -     +     +        -  -  [ low*a.high, high,a.low ]
//    -     -     -     +        -  -  [ low*a.high, low*a.low ]
//    -     -     -     -        +  +  [ high*a.high, low * a.low ]
//
template<class IT> interval<IT>& interval<IT>::operator*=( const interval<IT>& a )
   {
   IT l, h, t;

   if( low >= (IT)0 ) // 
      { // both low and high >= 0
      if( a.lower() >= (IT)0 )
         { // a.low >=0, a.high >= 0
         _controlfp( _RC_DOWN, _MCW_RC );
         l = low * a.lower();
         _controlfp( _RC_UP, _MCW_RC );
         h = high * a.upper();
         }
      else
         if( a.upper() >= (IT)0 )
            {  //  a.low < 0, a.high >= 0
            _controlfp( _RC_DOWN, _MCW_RC );
            l = high * a.lower();
            _controlfp( _RC_UP, _MCW_RC );
            h = high * a.upper();
            }
         else
            { // a.low and a.high < 0 
            _controlfp( _RC_DOWN, _MCW_RC );
            l = high * a.lower();
            _controlfp( _RC_UP, _MCW_RC );
            h = low * a.upper();
            }
      }
   else
      if( high >= (IT)0 )
         {  // low < 0, high >= 0
         if( a.lower() >= (IT)0 )
            { // a.low >=0, a.high >= 0
            _controlfp( _RC_DOWN, _MCW_RC );
            l = low * a.upper();
            _controlfp( _RC_UP, _MCW_RC );
            h = high * a.upper();
            }
         else
            if( a.upper() >= (IT)0 )
               {  //  a.low < 0, a.high >= 0
               _controlfp( _RC_DOWN, _MCW_RC );
               l = low * a.upper(); if ( l > ( t = high * a.lower() ) ) l = t;
               _controlfp( _RC_UP, _MCW_RC );
               h = high * a.upper(); if ( h < ( t = low * a.lower() ) ) h = t;
               }
            else
               { // a.low and a.high < 0 
               _controlfp( _RC_DOWN, _MCW_RC );
               l = high * a.lower();
               _controlfp( _RC_UP, _MCW_RC );
               h = low * a.lower();
               }
         }
      else
         { // low and high are < 0 
         if( a.lower() >= (IT)0 )
            { // a.low >=0, a.high >= 0
            _controlfp( _RC_DOWN, _MCW_RC );
            l = low * a.upper();
            _controlfp( _RC_UP, _MCW_RC );
            h = high * a.lower();
            }
         else
            if( a.upper() >= (IT)0 )
               {  //  a.low < 0, a.high >= 0
               _controlfp( _RC_DOWN, _MCW_RC );
               l = low * a.upper(); 
               _controlfp( _RC_UP, _MCW_RC );
               h = low * a.lower();
               }
            else
               { // a.low and a.high < 0 
               _controlfp( _RC_DOWN, _MCW_RC );
               l = high * a.upper();
               _controlfp( _RC_UP, _MCW_RC );
               h = low * a.lower();
               }
        }

   _controlfp( _RC_NEAR, _MCW_RC );

   low = l;
   high = h;

   return *this;
   }


// Specilization for float_precision and *= operator
//
interval<float_precision>& interval<float_precision>::operator*=( const interval<float_precision>& a )
   {
   float_precision l, h, t;

   l.precision( low.precision() );
   h.precision( low.precision() );   
   t.precision( low.precision() );

   l.mode( ROUND_DOWN );
   h.mode( ROUND_UP );

   if( low.sign() > 0 ) // 
      { // both low and high >= 0
      if( a.lower().sign() > 0 )
         { // a.low >=0, a.high >= 0
         l = low;  l *= a.lower();
         h = high; h *= a.upper();
         }
      else
         if( a.upper().sign() > 0 )
            {  //  a.low < 0, a.high >= 0
            l = high;  l *= a.lower();
            h = high; h *= a.upper();
            }
         else
            { // a.low and a.high < 0 
            l = high; l *= a.lower();
            h = low;  h *= a.upper();
            }
      }
   else
      if( high.sign() > 0 )
         {  // low < 0, high >= 0
         if( a.lower().sign() > 0 )
            { // a.low >=0, a.high >= 0
            l = low;  l *= a.upper();
            h = high; h *= a.upper();
            }
         else
            if( a.upper().sign() > 0 )
               {  //  a.low < 0, a.high >= 0
               t.mode( ROUND_DOWN );
               l = low;  l *= a.upper(); if( l > ( t = high, t *= a.lower() ) ) l = t;
               t.mode( ROUND_UP );
               h = high; h *= a.upper(); if( h < ( t = low, t *= a.lower() ) ) h = t;
               }
            else
               { // a.low and a.high < 0 
               l = high; l *= a.lower();
               h = low;  h *= a.lower();
               }
         }
      else
         { // low and high are < 0 
         if( a.lower().sign() > 0 )
            { // a.low >=0, a.high >= 0
            l = low;  l *= a.upper();
            h = high; h *= a.lower();
            }
         else
            if( a.upper().sign() > 0 )
               {  //  a.low < 0, a.high >= 0
               l = low; l *= a.upper(); 
               h = low; h *= a.lower();
               }
            else
               { // a.low and a.high < 0 
               l = high; l *= a.upper();
               h = low; h *= a.lower();
               }
        }

   low = l;
   high = h;

   return *this;
   }

// Works for all other classes
//
template<class IT> interval<IT>& interval<IT>::operator/=( const interval<IT>& b )
   {
   interval<IT> a, c;

   _controlfp( _RC_DOWN, _MCW_RC );
   c.low = (IT)1 / b.upper();

   _controlfp( _RC_UP, _MCW_RC );
   c.high = (IT)1 / b.lower();

   _controlfp( _RC_NEAR, _MCW_RC );

   a = interval( low, high );
   c *= a;

   low = c.lower();
   high = c.upper();

   return *this; 
   }

// Specilization for float_precision and /=
//
interval<float_precision>& interval<float_precision>::operator/=( const interval<float_precision>& b )
   {
   float_precision l = b.upper(), h = b.lower();
   interval<float_precision> c(b);

   l.mode( ROUND_DOWN );
   l = _float_precision_inverse( l );

   h.mode( ROUND_UP );
   h = _float_precision_inverse( h );

   c = interval<float_precision>( l , h );
   *this *= c;

   return *this;
   }

// Specilization for int_precision and /=
//
interval<int_precision>& interval<int_precision>::operator/=( const interval<int_precision>& b )
   {
   float_precision l = b.upper(), h = b.lower();
   interval<float_precision> c(b), a(*this);

   l.mode( ROUND_DOWN );
   l = _float_precision_inverse( l );

   h.mode( ROUND_UP );
   h = _float_precision_inverse( h );

   c = interval<float_precision>( l , h );
   a *= c;

   low = (int_precision)floor( a.lower() );
   high = (int_precision)ceil( a.upper() );

   return *this;
   }

// Specialization for int and /=
//
interval<int>& interval<int>::operator/=( const interval<int>& b )
   {
   double tlow, thigh;
   interval<int> a;
   interval<double> c;

   _controlfp( _RC_DOWN, _MCW_RC );
   tlow = 1 / (double)b.upper();

   _controlfp( _RC_UP, _MCW_RC );
   thigh = 1 / (double)b.lower();

   _controlfp( _RC_NEAR, _MCW_RC );

   a = interval( low, high );
   c = interval<double>( tlow, thigh );
   c *= a;

   low = (int)floor( c.lower() );
   high = (int)ceil( c.upper() );

   return *this; 
   }


// Binary + operator
// Works for all classes
//
template<class IT> interval<IT> operator+( const interval<IT>& a, const interval<IT>& b )
   {
   interval<IT> c(a);

   c += b; 
   
   return c;
   }


// Unary + operator
// Works for all classes
//
template<class IT> interval<IT> operator+( const interval<IT>& a )
   {
   return a;
   }

// Binary - operator
// Works for all classes
//
template<class IT> interval<IT> operator-( const interval<IT>& a, const interval<IT>& b )
   {
   interval<IT> c(a);

   c -= b;

   return c;
   }


// Unary - operator
// Works for all classes
//
template<class IT> interval<IT> operator-( const interval<IT>& a )
   {
   interval<IT> c(a);

   c = interval();
   c -= a;

   return c;
   }

// Binary * operator
// Works for all classes
//
template<class IT> interval<IT> operator*( const interval<IT>& a, const interval<IT>& b )
   {
   interval<IT> c(a);

   c *= b;

   return c;
   }

// Binary / operator
// Works for all classes
//
template<class IT> interval<IT> operator/( const interval<IT>& a, const interval<IT>& b )
   {
   interval<IT> c(a);

   if( c.lower() == b.lower() && c.upper() == b.upper() )
      c = interval<IT>(1,1);
   else
      c /= b;
   
   return c;
   }


// MSC sqrt() does not alllow rounding control
// So we have to do it manually
// However we do have H/W support in the intel CPUs
//
interval<double> sqrt( const interval<double>& x )
   {
   double lower, upper;
   
   lower = x.lower();
   upper = x.upper();
       
   _controlfp( _RC_DOWN, _MCW_RC );
   _asm { 
      fld qword ptr [ebp-8h];      Load lower into floating point stack
      fsqrt;                       Calculate sqrt
      fstp qword ptr [ebp-8h];     Store result in c.low
      }
  
   _controlfp( _RC_UP, _MCW_RC );
   _asm { 
      fld qword ptr [ebp-10h];     Load lower into floating point stack
      fsqrt;                       Calculate sqr
      fstp qword ptr [ebp-10h];    Store result in c.high
      }
   
   _controlfp( _RC_NEAR, _MCW_RC );

   return interval<double>( lower, upper );
   }

// Specilization for sqrt(float_precision)
// 
interval<float_precision> sqrt( const interval<float_precision>& x )
   {
   float_precision l, u;
   
   l.assign( x.lower() );  // Assign value, precision and mode
   l.mode( ROUND_DOWN );
   l = sqrt( l );

   u.assign( x.upper() );  // Assign value, precision and mode
   u.mode( ROUND_UP );
   u = sqrt( u );

   return interval<float_precision>( l, u );
   }

// MSC log() does not alllow rounding control
// So we have to do it manually
// However we do have H/W support in the intel CPUs
//
// 
interval<double> log( const interval<double>& x )
   {
   double lower, upper;
   
   lower = x.lower();
   upper = x.upper();

   _controlfp( _RC_DOWN, _MCW_RC );
   _asm { 
      fld qword ptr [ebp-8h];      Load lower into floating point stack
      fldln2;                      Load loge2
      fxch st(1);                  Exchange stack top 
      fyl2x;                       Calculate y * ln2 x
      fstp qword ptr [ebp-8h];     Store result in c.low
      }
   
   _controlfp( _RC_UP, _MCW_RC );
   _asm {
      fld qword ptr [ebp-10h];     Load lower into floating point stack
      fldln2;                      Load loge2
      fxch st(1);                  Exchange stack top 
      fyl2x;                       Calculate y * ln2 x
      fstp qword ptr [ebp-10h];    Store result in lower
      }

   _controlfp( _RC_NEAR, _MCW_RC );

   return interval<double>( lower, upper );
   }


// Specilization for log float_precision
// 
interval<float_precision> log( const interval<float_precision>& x )
   {
   float_precision l, u;
   
   l.assign( x.lower() );  // Assign value, precision and mode
   l.mode( ROUND_DOWN );
   l = log( l );

   u.assign( x.upper() );  // Assign value, precision and mode
   u.mode( ROUND_UP );
   u = log( u );

   return interval<float_precision>( l, u );
   }

// MSC log10() does not alllow rounding control
// So we have to do it manually
// However we do have H/W support in the intel CPUs
//
// 
interval<double> log10( const interval<double>& x )
   {
   double lower, upper;
   
   lower = x.lower();
   upper = x.upper();
       
   _controlfp( _RC_DOWN, _MCW_RC );
   _asm { 
      fld qword ptr [ebp-8h];      Load lower into floating point stack
      fldlg2;                      Load log10(2)
      fxch st(1);                  Exchange stack top 
      fyl2x;                       Calculate y * ln2 x
      fstp qword ptr [ebp-8h];     Store result in c.low
      }
   
   _controlfp( _RC_UP, _MCW_RC );
   _asm {
      fld qword ptr [ebp-10h];     Load lower into floating point stack
      fldlg2;                      Load log10(2)
      fxch st(1);                  Exchange stack top 
      fyl2x;                       Calculate y * ln2 x
      fstp qword ptr [ebp-10h];    Store result in lower
      }

   _controlfp( _RC_NEAR, _MCW_RC );

   return interval<double>( lower, upper );
   }


// Specilization for log float_precision
// 
interval<float_precision> log10( const interval<float_precision>& x )
   {
   float_precision l, u;
   
   l.assign( x.lower() );  // Assign value, precision and mode
   l.mode( ROUND_DOWN );
   l = log10( l );

   u.assign( x.upper() );  // Assign value, precision and mode
   u.mode( ROUND_UP );
   u = log10( u );

   return interval<float_precision>( l, u );
   }

// MSC exp() does not alllow rounding control
// So we have to do it manually
// Use a taylor series until their is no more change in the result
// exp(x) == 1 + x + x^2/2!+x^3/3!+....
//
interval<double> exp( const interval<double>& x )
   {
   int  i;
   interval<double> c, res, p0, old = 1;
   double dd;
//   char buf[128];
//   char buf2[128];

   p0 = x;
   old = interval<double>(1);
   res = interval<double>( 1 ) + p0;
   for( i = 2; i < 30 && ( res.lower() != old.lower() && res.upper() != old.upper() ); i++ )
      {
      old = res;
      p0 *= ( x / interval<double>( i ) );
      res += p0;
      dd = res.radius();
      //sprintf( buf, "%+.18g %+.18g", res.lower(), res.upper() );
      }

   //sprintf( buf2, "%+.18g", pow( 2.0, 3.0 ) );
   dd = res.radius();
   
   return res;
   }

// Specilization for log float_precision
// 
interval<float_precision> exp( const interval<float_precision>& x )
   {
   float_precision l, u;
   
   l.assign( x.lower() );  // Assign value, precision and mode
   l.mode( ROUND_DOWN );
   l = exp( l );

   u.assign( x.upper() );  // Assign value, precision and mode
   u.mode( ROUND_UP );
   u = exp( u );

   return interval<float_precision>( l, u );
   }

// MSC pow() does not alllow rounding control
// So we have to do it manually
// x^y == exp( y * ln( x ) ) );
//
// 
interval<double> pow( const interval<double>& x, const double y )
   {
   interval<double> c;

   c = log( x );
   c *= interval<double>( y );
   c = exp( c );

   return c;
   }

// Specilization for pow float_precision
// 

interval<float_precision> pow( const interval<float_precision>& x, const float_precision& y )
   {
   interval<float_precision> c(x);

   c = log( x );
   c *= interval<float_precision>( y );
   c = exp( c );

   return c;
   }


#endif
