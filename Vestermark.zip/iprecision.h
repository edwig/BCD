#ifndef INC_PRECISION
#define INC_PRECISION

/*
 *******************************************************************************
 *
 *
 *                       Copyright (c) 2002-2003
 *                       Future Team Aps 
 *                       Denmark
 *
 *                       All Rights Reserved
 *
 *   This source file is subject to the terms and conditions of the
 *   Future Team Software License Agreement which restricts the manner
 *   in which it may be used.
 *   Mail: hve@hvks.com
 *
 *******************************************************************************
*/

/*
 *******************************************************************************
 *
 *
 * Module name     :   iprecision.h
 * Module ID Nbr   :   
 * Description     :   Arbitrary integer precision class
 * --------------------------------------------------------------------------
 * Change Record   :   
 *
 * Version	Author/Date		Description of changes
 * -------  -----------		----------------------
 * 01.01		HVE/020209		Initial release
 * 01.01    HVE/030421     Use FFT for Fast multiplications. Clean up the code
 *                         Now it can be included in different compilation units
 *                         Without causing linker errors
 * 01.02    HVE/030514     % operator was speed optimized to the same speed as the
 *                         the / operator. Furthere more now both /, % operator
 *                         advantages of short_division or short_remainding 
 *                         speeding up the / and % operator
 * 01.03    HVE/030602     A bug for RADIX==BASE_256 in the udiv() and urem()
 *                         function. Quotient was initialized wrongly to "1" instead
 *                         of ICHARACTER(1)
 * 01.04    HVE/030722     A bug in ++ and -- operator did not increment/decrement
 *                         the variable
 * 01.05    HVE/011405     Subtraction of two eaul size number result in -0. this
 *                         has been corrected to +0.
 *                         BASE [2..9] is now also supported. All Base number <= 10
 *                         will be stored as character numbers.
 *                         Binary string can be read by using the notation "0bxxxx"
 *                         where x is either 0 or 1
 * 01.06    HVE/011905     Doxygen comments added
 * 01.07    HVE/050311     Replacing #define with inline functions *
 * 01.08    HVE/050314     Postfix ++ and -- implemented
 *
 * End of Change Record
 * --------------------------------------------------------------------------
*/


/* define version string */
static char _VI_[] = "@(#)iprecision.h 01.08 -- Copyright (C) Future Team Aps";


#include <string>
#include <complex>   // Need <complex> to support FFT functions for fast multiplications

// RADIX can either be 2,10 or 256!
static const int BASE_2	  = 2;
static const int BASE_8   = 8;
static const int BASE_10  = 10;
static const int BASE_16  = 16;
static const int BASE_256 = 256;

static const int RADIX = BASE_10;   // Set internal base for the arbitrary precision

inline std::string SIGN_STRING( int x )   { return x >=0 ? "+" : "-" ; }
inline int CHAR_SIGN( char x )            { return x == '-' ? -1 : 1; }
inline unsigned char IDIGIT( char x )     { return RADIX <= 10 ? (unsigned char)( x - '0') : (unsigned char)x; }
inline unsigned char IDIGIT10( char x )   { return (unsigned char)( x - '0'); }
inline unsigned char ICHARACTER( char x ) { return RADIX <= 10 ? (unsigned char)( x + '0') : (unsigned char)x; }
inline unsigned char ICHARACTER10( char x){ return (unsigned char)( x + '0'); }
inline int ICARRY( unsigned int x )       { return x / RADIX; }
inline int ISINGLE( unsigned int x )      { return x % RADIX; }


class int_precision;

// Arithmetic
inline int_precision operator+( int_precision&, int_precision& );
inline int_precision operator+( int_precision& );        // Unary 
inline int_precision operator++( int_precision& );       // Postfix Increment 
inline int_precision operator++( int_precision&, int );  // Postfix Increment 

inline int_precision operator-( int_precision&, int_precision& );
inline int_precision operator-( int_precision& );        // Unary
inline int_precision operator--( int_precision& );       // Postfix Decrement
inline int_precision operator--( int_precision&, int );  // Postfix Decrement

inline int_precision operator*( int_precision&, int_precision& );
inline int_precision operator/( int_precision&, int_precision& );
inline int_precision operator%( int_precision&, int_precision& );
inline int_precision operator<<( int_precision&, int_precision& );
inline int_precision operator>>( int_precision&, int_precision& );

// Boolean Comparision Operators
inline bool operator>( const int_precision&, const int_precision& );
inline bool operator<( const int_precision&, const int_precision& );
inline bool operator==( const int_precision&, const int_precision& );
inline bool operator!=( const int_precision&, const int_precision& );
inline bool operator>=( const int_precision&, const int_precision& );
inline bool operator<=( const int_precision&, const int_precision& );

// Core functions that works directly on String class and unsiged arithmetic
static std::string _int_precision_uadd( std::string *, std::string *);
static std::string _int_precision_uadd_short( std::string *, unsigned int );
static std::string _int_precision_usub( int *, std::string *, std::string *);
static std::string _int_precision_usub_short( int *, std::string *, unsigned int );
static std::string _int_precision_umul( std::string *, std::string *);
static std::string _int_precision_umul_short( std::string *, unsigned int );
static std::string _int_precision_umul_fourier( std::string *, std::string *);
static std::string _int_precision_udiv( std::string *, std::string *);
static std::string _int_precision_udiv_short( unsigned int *, std::string *, unsigned int );
static std::string _int_precision_urem( std::string *, std::string *);
static std::string _int_precision_uneg( std::string *);
static int _int_precision_compare( std::string *, std::string * );
static void _int_precision_strip_leading_zeros( std::string * );
static std::string _int_precision_itoa( const std::string * );
static std::string _int_precision_itoa( int_precision * );
static std::string _int_precision_atoi( const char *str );



///
/// @class int_precision
/// @author Henrik Vestermark (hve@hvks.com)
/// @date  9/7/2004
/// @version 1.0
/// @brief  This is an arbitrary integer class
///
/// @todo  	
///
/// Precision class
/// An Arbitrary integer always has the format [sign][digit]+ where sign is either '+' or '-'
/// the length or the representation is always >= 2
/// A null string is considered as an error and an exception is thrown
/// Also number is always strip for leading zeros
/// Since we always initiate to a valid int_precision number, it will never be a empty string
///
class int_precision
	{
   std::string mNumber;

   public:
      // Constructor
      int_precision( char c );      // When initialized through a char
      int_precision( int i );       // When initialized through an int
      int_precision( char *s );     // When initialized through a char string
      int_precision( const int_precision& s = int_precision(0) ): mNumber(s.mNumber) {}  // When initialized through another int_precision
         
      // Coordinate functions
      std::string copy() const   { return mNumber; }
      std::string *pointer()     { return &mNumber; }
      int sign() const           { return CHAR_SIGN( mNumber[0] ); }                    
      int change_sign()          { // Change and return sign   
                                 if( mNumber.length() != 2 || IDIGIT( mNumber[1] ) != 0 ) // Don't change sign for +0!
                                    if( mNumber[0] == '+' ) mNumber[0] = '-'; else mNumber[0] = '+';
                                 return CHAR_SIGN( mNumber[0] );
                                 }

      operator int() const       {// Conversion to int
                                 if( RADIX == BASE_10 ) 
                                    return atoi( mNumber.c_str() ); // Do it directly
                                 else 
                                    return atoi( _int_precision_itoa( &mNumber ).c_str() ); // Need to convert from RADIX to BASE_10 )
                                 }    
      operator double() const    {// Conversion to double
                                 if( RADIX == BASE_10 ) 
                                    return (double)atoi( mNumber.c_str() ); // Do it directly
                                 else  
                                    return (double)atoi( _int_precision_itoa( &mNumber ).c_str() ); // Need to convert from RADIX to BASE_10 )
                                 }    
                               

      // Essential operators
      int_precision& operator=( const int_precision& );
      int_precision& operator+=( const int_precision& );
      int_precision& operator-=( const int_precision& );
      int_precision& operator*=( const int_precision& );
      int_precision& operator/=( const int_precision& );
      int_precision& operator%=( const int_precision& );
      int_precision& operator>>=( const int_precision& );
      int_precision& operator<<=( const int_precision& );

      // Specialization
      friend ostream& operator<<( ostream& strm, const int_precision& d ) 
         { return strm << _int_precision_itoa( const_cast<int_precision *>(&d) ).c_str(); }
      friend istream& operator>>( istream& strm, int_precision& d )
         { 
         char ch; std::string s;
         strm >> ws >> ch; 
         if( ch == '+' || ch == '-' ) { s += ch; strm >> ch; } else s += '+';  // Parse sign

         if( ch == '0' ) // Octal or Hexadecimal number
            {
            strm >> ch;
            if( ch == 'x' || ch == 'X' ) // Parse Hexadecimal
               for( s += "0x"; ch >= '0' && ch <= '9' || ch >='a' && ch <= 'f' || ch >= 'A' || ch <= 'F'; strm >> ch ) s += ch;
            else
               if( ch == 'b' || ch == 'B' )  // Parse Binary
                  for( s += "0b"; ch >= '0' && ch <= '1'; strm >> ch ) s += ch;
               else // Parse Octal
                  for( s += "0"; ch >= '0' && ch <= '7'; strm >> ch ) s += ch;
            }
         else // Parse Decimal number
            for( ; ch >= '0' && ch <= '9'; strm >> ch ) s += ch;

         cin.putback( ch );  // ch contains the first character not part of the number, so put it back
         if(!strm.fail() && s.length() >= 2 )  // Valid number has at least a length of 2 or higher
            d = int_precision( const_cast<char *>( s.c_str() ) );

         return strm;
         }

      // Exception class
      class bad_int_syntax {}; 
      class out_of_range   {};
      class divide_by_zero {};
   };




///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	int_precision::int_precision
///	@return 	nothing
///	@param   "str"	-	Convert the character string number into a multi precision number
///
///	@todo  
///
/// Description:
///   Constructor 
///   Validate input and convert to internal representation
///   Always add sign if not specified 
///   Only use core base functions to create multi precision numbers
//
inline int_precision::int_precision( char *str )
   {
   std::string s(str);
   
   if( s.empty() )
      { throw bad_int_syntax(); return; }

   mNumber = _int_precision_atoi( str );
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	int_precision::int_precision
///	@return 	nothing
///	@param   "c"	-	the character integer to convert to multi precision number
///
///	@todo  
///
/// Description:
///   Constructor
///   Validate and initilize with a character
///   Input Always in BASE_10
///   Convert to the internal RADIX 
//
inline int_precision::int_precision( char c )
   {
   int i;

   if( c < '0' || c > '9' )
      throw bad_int_syntax(); 
   else
      { 
      i = c - '0';  // Convert to integer
      mNumber = "+";
      mNumber += ICHARACTER( (char)ISINGLE( i ) );
      }
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	int_precision::int_precision
///	@return 	nothing
///	@param   "i"	-	the binary integer to convert to multi precision number
///
///	@todo  
///
/// Description:
///   Constructor
///   Validate and initialize with an integer
///   Just convert integer to string representation in BASE RADIX
///   The input integer is always BASE_10
///   Only use core base functions to create multi precision numbers
//
inline int_precision::int_precision( int i )
   {
   int sign = 1;
   std::string number;

   if( i == 0 )
      {
      mNumber = "+";
      mNumber.append( 1, ICHARACTER( 0 ) );
      return;
      }

   if( i < 0 ) 
      { 
      i = -i;
      sign = -1;
      }

   if( RADIX == BASE_256 )  // Fast BASE_256 conversion
      {
      int j;
      unsigned char *p = (unsigned char *)&i;
      
      for( j = sizeof( int ); j > 0; j-- )
         if( p[j-1] != 0 )  // Strip leading zeros
            break;
      for( ; j > 0; j-- )
         number.append( 1, p[j-1] );
      }
   else
      {// All others
      for( ; i != 0; i /= RADIX )
         number.insert( (std::string::size_type)0, 1, ICHARACTER( (char)( i % RADIX ) ) );
      }

   mNumber = SIGN_STRING( sign ) + number;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator=
///	@return 	static int_precision	-	return a=b
///	@param   "a"	-	Assignment operand
///
///	@todo 
///
/// Description:
///   Assign operator
//
inline int_precision& int_precision::operator=( const int_precision& a )
   {
   mNumber = a.mNumber;

   return *this;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator+=
///	@return 	static int_precision	-	return a +=b
///	@param   "a"	-	Adding operand
///
///	@todo 
///
/// Description:
///   += operator
//
inline int_precision& int_precision::operator+=( const int_precision& a )
   {
   int sign1, sign2, wrap;
   std::string s1, s2;
	int cmp;

   // extract sign and unsigned portion of number
   sign1 = a.sign(); 
   s1 = a.mNumber.substr( 1 );
   sign2 = CHAR_SIGN( mNumber[0] );
   s2 = mNumber.substr( 1 );

   if( sign1 == sign2 )
      mNumber = SIGN_STRING( sign1 ) + _int_precision_uadd( &s1, &s2 );
   else
      {
		cmp = _int_precision_compare( &s1, &s2 );
		if( cmp > 0 ) // Since we subctract less the wrap indicater need not to be checked
         mNumber = SIGN_STRING(sign1) + _int_precision_usub( &wrap, &s1, &s2 );
      else
			if( cmp < 0 )
				mNumber = SIGN_STRING(sign2) + _int_precision_usub( &wrap, &s2, &s1 );
			else
				mNumber = std::string( "+0" );
		}
   
   return *this;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator-=
///	@return 	static int_precision	-	return a -=b
///	@param   "a"	-	Subtracting operand
///
///	@todo 
///
/// Description:
///   -= operator
///   The essential -= operator
///   n = n - a is the same as n = n + (-a); 
//
inline int_precision& int_precision::operator-=( const int_precision& a )
   {
   int_precision b;

   b = a;
   b.change_sign();
   *this += b;

   return *this;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator*=
///	@return 	static int_precision	-	return a *=b
///	@param   "a"	-	Multiplying operand
///
///	@todo 
///
/// Description:
///   *= operator
//
inline int_precision& int_precision::operator*=( const int_precision& a )
   {
   int sign1, sign2;
   std::string s1, s2;

   // extract sign and unsigned portion of number
   sign1 = a.sign();
   s1 = a.mNumber.substr( 1 );
   sign2 = CHAR_SIGN( mNumber[0] );
   s2 = mNumber.substr( 1 );

   sign1 *= sign2;
   mNumber = SIGN_STRING( sign1 ) + _int_precision_umul_fourier( &s1, &s2 );
   if( sign1 == -1 && mNumber.length() == 2 && IDIGIT( mNumber[1] ) == 0 )  // Avoid -0 as result +0 is right
      mNumber[0] = '-';  // Change sign

   return *this;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator/=
///	@return 	static int_precision	-	return a /=b
///	@param   "a"	-	Dividing operand
///
///	@todo 
///
/// Description:
///   /= operator
//
inline int_precision& int_precision::operator/=( const int_precision& a )
   {
   int sign1, sign2;
   std::string s1, s2;

   // extract sign and unsigned portion of number
   sign1 = CHAR_SIGN(mNumber[0] );
   s1 = mNumber.substr( 1 );
   sign2 = a.sign();
   s2 = a.mNumber.substr( 1 );

   sign1 *= sign2;
   mNumber = SIGN_STRING( sign1 ) + _int_precision_udiv( &s1, &s2 );
   if( sign1 == -1 && mNumber.length() == 2 && IDIGIT( mNumber[1] ) == 0 )  // Avoid -0 as result +0 is right
      mNumber[0] = '+';

   return *this;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator%=
///	@return 	static int_precision	-	return a %=b
///	@param   "a"	-	Modulus operand
///
///	@todo 
///
/// Description:
///   %= operator
//
inline int_precision& int_precision::operator%=( const int_precision& a )
   {
   int sign1, sign2;
   std::string s1, s2;

   // extract sign and unsigned portion of number
   sign1 = CHAR_SIGN(mNumber[0] );
   s1 = mNumber.substr( 1 );
   sign2 = a.sign();
   s2 = a.mNumber.substr( 1 );

   mNumber = SIGN_STRING( sign1 ) + _int_precision_urem( &s1, &s2 );
   if( sign1 == -1 && mNumber.length() == 2 && IDIGIT( mNumber[1] ) == 0 )  // Avoid -0 as result +0 is right
      mNumber[0] = '+';

   return *this;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator<<=
///	@return 	static int_precision	-	return shifting a<<= b
///	@param   "a"	-	Shifting number
///
///	@todo 
///
/// Description:
///   <<= operator
//
inline int_precision& int_precision::operator<<=( const int_precision& a )
   {
   int sign1, sign2, wrap;;
   std::string s1, s2;
   std::string c0, c3, c8;

   c0.insert( (std::string::size_type)0, 1, ICHARACTER( 0 ) );
   // extract sign and unsigned portion of number
   sign1 = CHAR_SIGN(mNumber[0] );
   s1 = mNumber.substr( 1 );
   sign2 = a.sign();
   s2 = a.mNumber.substr( 1 );

   if( sign2 < 0 )
      { throw out_of_range(); return *this; }

   // Speed up the operation by shifting the native if possible
   if( RADIX == BASE_256 )
      {// BASE 256 Shift 8 bit a a time if possible
      c8.insert( (std::string::size_type)0, 1, ICHARACTER( 8 ) );
      for( ; _int_precision_compare( &s2, &c8 ) >= 0; s2 = _int_precision_usub_short( &wrap, &s2, 8 ) )
         s1 = _int_precision_umul_short( &s1, BASE_256 );  //2<<7==256 or 2^8
      }
   else
      if( RADIX == BASE_10 )
			{ // BASE 10 shift 3 bit at a time if possible
			c3.insert( (std::string::size_type)0, 1, ICHARACTER( 3 ) );
			for( ; _int_precision_compare( &s2, &c3 ) >= 0; s2 = _int_precision_usub_short( &wrap, &s2, 3 ) )
				s1 = _int_precision_umul_short( &s1, BASE_8 );  //2<<2==8 or 2^3
			}
		else
			if( RADIX == BASE_2 )
            { // BASE 2
				int shift;  // Don't shift. just add zeros number of shift times!

	         s2.insert( 0, "+" );
	         shift = atoi( _int_precision_itoa( &s2 ).c_str() ); // Need to convert from RADIX to BASE_10 )
				s1.append( shift, ICHARACTER( 0 ) );
				s2 = ICHARACTER(0);
				}

   // Take the remainds of shifts
   if( _int_precision_compare( &s2, &c0 ) > 0 )
      {
      int shift;

      if( RADIX == BASE_10 ) 
         shift = atoi( s2.c_str() ); // Do it directly
      else 
         {
         s2.insert( 0, "+" );
         shift = atoi( _int_precision_itoa( &s2 ).c_str() ); // Need to convert from RADIX to BASE_10
			s2 = s2.substr( 1 );
         }

		if( RADIX >= BASE_10 )
			s1 = _int_precision_umul_short( &s1, 2 << ( shift - 1 ) ); 
		else
			{
			for( ; shift > 0; --shift )
				s1 = _int_precision_umul_short( &s1, 2 ); 
			}
      }

   mNumber = SIGN_STRING( sign1 ) + s1;
   
   return *this;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator>>=
///	@return 	static int_precision	-	return shifting a>>= b
///	@param   "a"	-	Shifting operand
///
///	@todo 
///
/// Description:
///   >>= operator
//
inline int_precision& int_precision::operator>>=( const int_precision& a )
   {
   int sign1, sign2, wrap;
   unsigned int rem;
   std::string s1, s2;
   std::string c0, c3, c8;
   
   c0.insert((std::string::size_type)0, 1, ICHARACTER(0) );
   // extract sign and unsigned portion of number
   sign1 = CHAR_SIGN(mNumber[0] );
   s1 = mNumber.substr( 1 );
   sign2 = a.sign();
   s2 = a.mNumber.substr( 1 );

   if( sign2 < 0 )
      { throw out_of_range(); return *this; }

   if( RADIX == BASE_256 )  // Speed up by alowing shift with 8 at a time instead of single shift
      {
      c8.insert( (std::string::size_type)0, 1, ICHARACTER( 8 ) );

      for( ; _int_precision_compare( &s2, &c8 ) >= 0; s2 = _int_precision_usub_short( &wrap, &s2, 8 ) )
         s1 = _int_precision_udiv_short( &rem, &s1, BASE_256 ); //2<<7==256 or 2^8
      }
   else
		if( RADIX == BASE_10 ) // Speed up by alowing shift with 8 at a time instead of single shift
			{
			c3.insert( (std::string::size_type)0, 1, ICHARACTER( 3 ) );

			for( ; _int_precision_compare( &s2, &c3 ) >= 0; s2 = _int_precision_usub_short( &wrap, &s2, 3 ) )
				s1 = _int_precision_udiv_short( &rem, &s1, BASE_8 ); //2<<2==8 or 2^3
			}
		else
			if( RADIX == BASE_2 ) // Speed up trick for binary shifts
				{
				int shift;

	         s2.insert( 0, "+" );
	         shift = atoi( _int_precision_itoa( &s2 ).c_str() ); // Need to convert from RADIX to BASE_10 )
				if( (int)s1.size() <= shift )
					s1 = ICHARACTER( 0 );
				else
					s1 = s1.substr( 0, s1.size() - shift );
				s2 = ICHARACTER(0);
				}

   // Take the remainds of shifts less after applying the speed up trick
   if( _int_precision_compare( &s2, &c0 ) > 0 )
      {
      int shift;

      if( RADIX == BASE_10 ) 
         shift = atoi( s2.c_str() ); // Do it directly
      else 
         {
         s2.insert( 0, "+" );
         shift = atoi( _int_precision_itoa( &s2 ).c_str() ); // Need to convert from RADIX to BASE_10 )
			s2 = s2.substr( 1 );
         }

		if( RADIX >= BASE_10 )
			s1 = _int_precision_udiv_short( &rem, &s1, 2 << ( shift - 1 ) );
		else
			for( ; shift > 0; --shift )
				s1 = _int_precision_udiv_short( &rem, &s1, 2 );
      }

   mNumber = SIGN_STRING( sign1 ) + s1;
   if( sign1 == -1 && mNumber.length() == 2 && IDIGIT( mNumber[1] ) == 0 )  // Avoid -0 as result +0 is right
      mNumber[0] = '+';
   
   return *this;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator+
///	@return 	static int_precision	-	return addition of a - b
///	@param   "lhs"	-	First operand
///	@param   "rhs"	-	Second operand
///
///	@todo 
///
/// Description:
///   Add operator
//
static int_precision operator+( int_precision& lhs, int_precision& rhs )
   {
   return int_precision(lhs) += rhs; 
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator+
///	@return 	static int_precision	-	a
///	@param   "a"	-	operand 
///
///	@todo 
///
/// Description:
///   Unary + operator
///   Do nothing
//
static int_precision operator+( int_precision& a )
   {
   return a;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator++ Prefix
///	@return 	int_precision	-	return the incremented a
///	@param   "a"	-	operand
///
///	@todo 
///
/// Description:
///   Increment operator
//
static int_precision operator++( int_precision& a )
   {
   a += int_precision( 1 );
   return a;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  3/14/2005
///	@brief 	operator++ Postfix
///	@return 	int_precision	-	return the a before incrementation
///	@param   "a"	-	operand
///
///	@todo 
///
/// Description:
///   Postfix Increment operator
//
int_precision operator++( int_precision& a, int )
   {
   int_precision postfix_a(a);

   a += int_precision( 1 );
   return postfix_a;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator-
///	@return 	static int_precision	-	return subtraction of a - b
///	@param   "a"	-	First operand
///	@param   "b"	-	Second operand
///
///	@todo 
///
/// Description:
///   Subtract operator
//
static int_precision operator-( int_precision& lhs, int_precision& rhs )
   {
   return int_precision(lhs) -= rhs;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator%
///	@return 	static int_precision	-	-a
///	@param   "a"	-	operand for sign change
///
///	@todo 
///
/// Description:
///   Unary - operator
///   Change sign
//
static int_precision operator-( const int_precision& a )
   {
   int_precision b;

   b = a;
   b.change_sign();
   
   return b;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator-- prefix
///	@return 	int_precision	-	return the decremented a
///	@param   "a"	-	operand
///
///	@todo 
///
/// Description:
///   Decrement operator
//
static int_precision operator--( int_precision& a )
   {
   a -= int_precision( 1 );
   return a;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  3/14/2005
///	@brief 	operator-- postfix
///	@return 	int_precision	-	return the a before decrementation
///	@param   "a"	-	operand
///
///	@todo 
///
/// Description:
///   Postfix Decrement operator
//
int_precision operator--( int_precision& a, int )
   {
   int_precision postfix_a(a);
   a -= int_precision( 1 );
   return postfix_a;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator%
///	@return 	static int_precision	-	return multiplication of a * b
///	@param   "lhs"	-	First operand
///	@param   "rhs"	-	Second operand
///
///	@todo 
///
/// Description:
///   Multiply operator
//
static int_precision operator*( int_precision& lhs, int_precision& rhs )
   {
   return int_precision(lhs) *= rhs;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator%
///	@return 	static int_precision	-	return division of a / b
///	@param   "lhs"	-	First operand
///	@param   "rhs"	-	Second operand
///
///	@todo 
///
/// Description:
///   Division operator
//
static int_precision operator/( int_precision& lhs, int_precision& rhs )
   {
   return int_precision(lhs) /= rhs;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator%
///	@return 	static int_precision	-	return module of a % b
///	@param   "lhs"	-	First operand
///	@param   "rhs"	-	Second operand
///
///	@todo 
///
/// Description:
///   Modulo operator
//
static int_precision operator%( int_precision& lhs, int_precision& rhs )
   {
   return int_precision(lhs) %= rhs;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator>>
///	@return 	static int_precision	-	return the shifted number
///	@param   "lhs"	-	number to shift
///	@param   "rhs"	-	number of shifts
///
///	@todo  
///
/// Description:
///   Shift Left
//
static int_precision operator<<( int_precision& lhs, int_precision& rhs )
   {
   return int_precision(lhs) <<= rhs;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	operator>>
///	@return 	static int_precision	-	return the shifted number
///	@param   "rhs"	-	number to shift
///	@param   "lhs"	-	number of shifts
///
///	@todo  
///
/// Description:
///   Shift Right
//
static int_precision operator>>( int_precision& lhs, int_precision& rhs )
   {
   return int_precision(lhs) >>= rhs;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 			operator==
///	@return 			static bool	- 	the boolean value of the operator
///	@param "a"	-	First operand number to compare
///	@param "b"	-	Second operand number to 
///
///	@todo
///
/// Description:
///   Boolean equal of two precision numbers. Early out algorithm
///   1) if sign different then result is false. We actual don't do this test because of -0==+0 we should not ocuured but just in case
///   2) if length is different then the result is false
///   3) use core compare to determine boolean value
//
static bool operator==( const int_precision& a, const int_precision& b )
   {
   // Different signs
   //  if( a.sign() != b.sign() )
   //    return false;

   if( const_cast<int_precision&>(a).pointer()->length() != const_cast<int_precision&>(b).pointer()->length() ) // Different therefore false
      return false;
   else
      if( _int_precision_compare( const_cast<int_precision&>(a).pointer(), const_cast<int_precision&>(b).pointer() ) == 0 )   // Same return true
         return true;
   
   return false;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 			operator<
///	@return 			static bool	- 	the boolean value of the operator
///	@param "a"	-	First operand number to compare
///	@param "b"	-	Second operand number to 
///
///	@todo
///
/// Description:
///   Boolean less of two precision numbers. Early out algorithm for higher performance
///   1) If sign different determine boolean result based on sign
///   2) Otherwise determine boolean result based length of number amnd the sign
///   3) Same sign and same length. Do a core comparison and return the result
//
static bool operator<( const int_precision& a, const int_precision& b )
   {
   int sign1, sign2, cmp;

   sign1 = a.sign(); 
   sign2 = b.sign(); 

   // Different signs
   if( sign1 > sign2 )
      return false;
   if( sign1 < sign2 )
      return true;

   // Same sign
   if( sign1 == 1 && const_cast<int_precision&>(a).pointer()->length() < const_cast<int_precision&>(b).pointer()->length() ) // Different therefore true
      return true;
   if( sign1 == 1 && const_cast<int_precision&>(a).pointer()->length() > const_cast<int_precision&>(b).pointer()->length() ) // Different therefore false
      return false;
   if( sign1 == -1 && const_cast<int_precision&>(a).pointer()->length() > const_cast<int_precision&>(b).pointer()->length() )
      return true;
   if( sign1 == -1 && const_cast<int_precision&>(a).pointer()->length() < const_cast<int_precision&>(b).pointer()->length() )
      return false;

   // Same sign and same length
   cmp = _int_precision_compare( const_cast<int_precision&>(a).pointer(), const_cast<int_precision&>(b).pointer() );
   if( cmp < 0 && sign1 == 1 )
      return true;
   else
      if( cmp > 0 && sign1 == -1 )
         return true;
   
   return false;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 			operator!=
///	@return 			static bool	- 	the boolean value of the operator
///	@param "a"	-	First operand number to compare
///	@param "b"	-	Second operand number to 
///
///	@todo
///
/// Description:
///   Boolean not equal of two precision numbers
//
static bool operator!=( const int_precision& a, const int_precision& b )
   {
   return b == a ? false : true;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 			operator>
///	@return 			static bool	- 	the boolean value of the operator
///	@param "a"	-	First operand number to compare
///	@param "b"	-	Second operand number to 
///
///	@todo
///
/// Description:
///   Boolean greater of two precision numbers
//
static bool operator>( const int_precision& a, const int_precision& b )
   {
   return b < a ? true : false;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 			operator<=
///	@return 			static bool	- 	the boolean value of the operator
///	@param "a"	-	First operand number to compare
///	@param "b"	-	Second operand number to 
///
///	@todo
///
/// Description:
///   Boolean less or equal of two precision numbers
//
static bool operator<=( const int_precision& a, const int_precision& b )
   {
   return b < a ? false : true;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 			operator>=
///	@return 			static bool	- 	the boolean value of the operator
///	@param "a"	-	First operand number to compare
///	@param "b"	-	Second operand number to 
///
///	@todo
///
/// Description:
///   Boolean greater or equal of two precision numbers
//
static bool operator>=( const int_precision& a, const int_precision& b )
   {
   return a < b ? false: true;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	std::string _int_precision_itoa Convert number to ascii string
///	@return 	static	-	the converted number in ascii string format
///	@param   "a"	-	Number to convert to ascii
///
///	@todo 
///
/// Description:
///   Convert int_precsion to ascii string
///   Based on RADIX convertion from RADIX to BASE_10
//
static std::string _int_precision_itoa( int_precision *a )
   {
   return _int_precision_itoa( a->pointer() );
   }

//
// Core functions
// The core functions all performe unsigned aitrhmetic un elements of the string class!
//    _int_precision_strip_leading_zeros -- Strips non significant leading zeros
//    _int_precision_compare     -- compare two strings for numeric order
//    _int_precision_uneg        -- Negate ones-complement of unsigned integer
//    _int_precision_uadd_short  -- add a short digit [0..RADIX] to the string
//    _int_precision_uadd        -- add two unsigned strings
//    _int_precision_usub_short  -- subtract a short digit [0..RADIX] from the string
//    _int_precision_usub        -- subtract two unsigned strings
//    _int_precision_umul_short  -- multiply a short digiti [0..RADIX] to the string
//    _int_precision_umul        -- multiply two unsigned strings
//    _int_precision_udiv_short  -- Divide a short digit [0..RADIX] to the string
//    _int_precision_udiv        -- divide two unsinged strings
//    _int_precision_urem        -- remainder of dividing two unsinged strings
//    _int_precision_itoa        -- Convert internal precision to BASE_10 string
//    _int_reverse_binary        -- Reverse bit the data buffer
//    _int_fourier               -- Fourier transformn the data
//    _int_real_fourier          -- Convert n discrete double data into a fourier transform data set
//

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	_int_reverse_binary
///	@return 	static void	-	
///	@param   "data[]"	-	array of double complex number to permute
///	@param   "n"	-	number of element in data[]
///
///	@todo  
///
/// Description:
///   Reverse binary permute
///   n must be a power of 2
//
static void _int_reverse_binary( std::complex<double> data[], unsigned int n )
   {
   unsigned int i, j, m;

   if( n <=2 ) return;

   j = 1;
   for( i = 1; i < n; i++ )
      {
      if( j > i ) 
         std::swap( data[ j - 1 ], data[ i - 1 ] );
 
      for( m = n >> 1; m >= 2 && j > m; m >>= 1 )
         j -= m;

      j += m;
      }
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	_int_fourier do the fourier transformation
///	@return 	static void	-	
///	@param   "data[]"	-	complex<double> fourie data
///	@param   "n"	-	number of element in data (must be a power of 2)
///	@param   "isign"	-	transform in(1) or out(-1)
///
///	@todo
///
/// Description:
///   Wk=exp(2* PI *i *j )  j=0..n/2-1
///   exp( k * i *j ) => exp( k * i * (j-1) + k * i ) => exp( t + o ) for each new step
///   exp( t + o ) => exp(t)-exp(t)*( 1 - cos(o) -isin(o) ) => exp(t)-exp(t)*(a-ib)
///   => exp(t)+exp(t)*(-a+ib) => exp(t)( 1 + (-a+b) )
///   sin(t+o)=sin(t)+[-a*sin(t)+b*cos(t)]
///   a=2sin^2(o/2), b=sin(o)
///   n must be a power of 2
//
static void _int_fourier( std::complex<double> data[], unsigned int n, int isign )
   {
   double theta;
   std::complex<double> w, wp;
   unsigned long mh, m, r, j, i;

   _int_reverse_binary( data, n );

   for( m = 2; n >= m; m <<= 1 )
      {
      theta = isign * 2 * 3.14159265358979323846264 / m;
      wp = std::complex<double>( -2.0 * sin( 0.5 * theta ) * sin( 0.5 * theta ), sin( theta ) );
      w = std::complex<double> ( 1, 0 ); // exp(0) == exp( isign*2*PI*i/mmax * m-1 )
      mh = m >> 1;

      for( j = 0; j < mh; j++ )      // m/2 iteration
         {
         for( r = 0; r <= n - m; r += m )
            {
            std::complex<double> tempc;
            i = r + j;
            tempc = w * data[ i + mh ];              // u=data[i]; v=data[j]*w; data[i]=u+v;data[j]=u-v;
            data[ i + mh ] = data[ i ] - tempc;
            data[ i ] += tempc;
            }
      
         w =  w * wp + w;  // w = w(1+wp) ==> w *=1+wp;
         }
      }
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 			_int_real_fourier
///	@return 			static void	-	
///	@param   "data[]"	-	
///	@param   "n"	-	number of data element in data. n must be a power of 2)
///	@param   "isign"	-	Converting in(1) or out(-1)
///
///	@todo  
///
/// Description:
///   Convert n discrete double data into a fourier transform data set
///   n must be a power of 2
//
static void _int_real_fourier( double data[], unsigned int n, int isign )
   {
   int i;
   double theta, c1 = 0.5, c2;
   std::complex<double> w, wp, h1, h2;

   theta = 3.14159265358979323846264 / (double)( n >> 1 );
   if( isign == 1 )
      {
      c2 = -c1;
      _int_fourier( (std::complex<double> *)data, n >> 1, 1 );
      }
   else
      {
      c2 = c1;
      theta = -theta;
      }
   wp = std::complex<double>( -2.0 * sin( 0.5 * theta ) * sin( 0.5 * theta ), sin( theta ) );
   w = std::complex<double> ( 1 + wp.real(), wp.imag() );
   for( i = 1; i < (n>>2); i++ )
      {
      int i1, i2, i3, i4;
      std::complex<double> tc;

      i1 = i + i;
      i2 = i1 + 1;
      i3 = n + 1 - i2;
      i4 = i3 + 1;
      h1 = std::complex<double> ( c1 * ( data[i1] + data[i3] ), c1 * ( data[i2]-data[i4]));
      h2 = std::complex<double> ( -c2 * ( data[i2]+data[i4] ), c2 * ( data[i1]-data[i3]));
      tc = w * h2;
      data[i1]=h1.real()+tc.real();
      data[i2]=h1.imag()+tc.imag();
      data[i3]=h1.real() - tc.real();
      data[i4]=-h1.imag() + tc.imag();
      w *= ( std::complex<double>(1) + wp );
      }
   if( isign == 1 )
      {
      double t;
      data[0] = (t=data[0]) + data[1];
      data[1] = t - data[1];
      }
   else
      {
      double t;
      data[0]=c1*((t=data[0])+data[1]);
      data[1]=c1*(t-data[1]);
      _int_fourier( (std::complex<double> *)data, n>>1, -1 );
      }
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	_int_precision_strip_leading_zeros
///	@return 	static void	-	
///	@param   "s"	-	pointer to source operand
///
///	@todo
///
/// Description:
///   Remove leading nosignificant zeros
//
static void _int_precision_strip_leading_zeros( std::string *s )
   {
   std::string::iterator pos;

   // Strip leading zeros
   for( pos = s->begin(); pos != s->end() && IDIGIT( *pos ) == 0; )
         s->erase( pos );
      
   if( s->empty() )
      *s = ICHARACTER(0);

   return;
   }

///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 	_int_precision_compare
///	@return 	int	-	Yhe compare result. o==equal, 1==s1>s2, -1==s1<s2
///	@param   "s1"	-	First operand to compare
///	@param   "s2"	-	Second operand to compare
///
///	@todo  
///
/// Description:
///   Compare two unsigned decimal string 
///   and return 0 is equal, 1 if s1 > s2 otherwise -1
///   Optimized checl length first and determine 1 or -1 if equal
///   compare the strengths.
//
static int _int_precision_compare( std::string *s1, std::string *s2 )
   {
   int cmp;

   if( s1->length() > s2->length() )
      cmp = 1;
   else
      if( s1->length() < s2->length() )
         cmp = -1;
      else
         cmp = s1->compare( *s2 );

   return cmp;
   }



///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/19/2005
///	@brief 			std::string _int_precision_uneg
///	@return 			std::string	- The negated number	
///	@param         "src"	-	The number to negate
///
///	@todo
///
/// Description:
///   Negate one-complement the unsinged integer src
//
static std::string _int_precision_uneg( std::string *src )
   {
   unsigned short ireg = RADIX;
   std::string::reverse_iterator r_pos;
   std::string des;

   des = *src;
   r_pos = des.rbegin();

   for(; r_pos != des.rend(); ++r_pos )
      {
      ireg = RADIX - 1 - IDIGIT( *r_pos ) + ICARRY( ireg );
      *r_pos = ICHARACTER( ISINGLE( ireg ) );
      }

   return des;
   }




///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/14/2005
///	@brief 		std::string _int_precision_uadd_short
///	@return 		std::string - 	the result of the add
///	@param      "src1"	-	Source string to add short number
///	@param      "d"	   -	Number to add.   
///
///	@todo
///
/// Description:
///   Short Add: The digit d [0..RADIX] is added to the unsigned decimal string
///   Optimized 0 add or early out add is implemented
///   Please note that uadd_short will throw an exception if d is larger than the 
///   RADIX of the internal representation. e.g. is RADIX is BASE_10 then d can
///   be in the range of 0..10. If base is BASE_2 the d can only be in hte range \
///   from 0..2
//
static std::string _int_precision_uadd_short( std::string *src1, unsigned int d )
   {
   unsigned short ireg;
   std::string::reverse_iterator r1_pos;
   std::string::reverse_iterator rd_pos;
   std::string des1;

   if( d > RADIX )
      {
      throw int_precision::out_of_range();
      des1.insert( (std::string::size_type)0, 1, ICHARACTER(0) );
      return des1;
      }

   if( d == 0 )   // Zero add
      return *src1;

   ireg = RADIX * d;
   des1 = *src1;
   rd_pos = des1.rbegin();
   r1_pos = src1->rbegin();
   
   for(; r1_pos != src1->rend(); ++r1_pos, ++rd_pos )
      {
      ireg = IDIGIT( *r1_pos ) + ICARRY( ireg ); 
      *rd_pos = ICHARACTER( ISINGLE( ireg ) );
      if( ICARRY( ireg ) == 0 ) // Early out add
         break;
      }

   if( ICARRY( ireg ) != 0 )  // Insert the carry in the front of the number
      des1.insert( (std::string::size_type)0, 1, ICHARACTER( ICARRY( ireg ) ) );

   _int_precision_strip_leading_zeros( &des1 );

   return des1;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/14/2005
///	@brief 	std::string _int_precision_uadd
///	@return 	std::string	-	the result of adding src1 and src2
///	@param   "src1"	-	First unsigned source argument
///	@param   "src2"	-	Second unsigned source argument
///
///	@todo
///
/// Description:
///   Add two unsigned decimal strings
///   Optimized: Used early out add
//
static std::string _int_precision_uadd( std::string *src1, std::string *src2 )
   {
   unsigned short ireg = 0;
   std::string des1;
   std::string::reverse_iterator r_pos, r_end, rd_pos;

   if( src1->length() >= src2->length() )
      {
      des1 = *src1; 
      r_pos = src2->rbegin();
      r_end = src2->rend();
      }
   else
      {
      des1 = *src2;
      r_pos = src1->rbegin();
      r_end = src1->rend();
      }
   rd_pos = des1.rbegin();
   
   for( ; r_pos != r_end; )
      { // Adding element by element for the two numbers
      ireg = IDIGIT( *r_pos ) + IDIGIT( *rd_pos ) + ICARRY( ireg );
      *rd_pos = ICHARACTER( ISINGLE( ireg ) );
      ++r_pos;
      ++rd_pos;
      }

   // Exhaust the smalles of the number, so only the carry can changes the uppper radix digits
   for( ; ICARRY( ireg ) != 0 && rd_pos != des1.rend(); )
      {
      ireg = IDIGIT( *rd_pos ) + ICARRY( ireg );
      *rd_pos = ICHARACTER( ISINGLE( ireg ) );
      ++rd_pos;
      }

   // No more carry or end of upper radix number. 
   if( ICARRY( ireg ) != 0 ) // If carry add the carry as a extra radix digit to the front of the number
      des1.insert( (std::string::size_type)0, 1, ICHARACTER( ICARRY( ireg ) ) );

   _int_precision_strip_leading_zeros( &des1 );

   return des1;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/14/2005
///	@brief 		std::string _int_precision_uadd_short
///	@return 		std::string - 	the result of the add
///	@param      "src1"	-	Source string to add short number
///	@param      "d"	   -	Number to add.   
///   @param        "result" - Indicated wrap around (1) or not (0)
///
///	@todo
///
/// Description:
///   Short subtract: The digit d [0..RADIX] is subtracted from the unsigned decimal string
///   if src1 < d result is set to -1 (wrap around) otherwise result is set to  0 (no wrap around)
///   Optimized 0 subtract
///   Please note that usub_short will throw an exception if d is larger than the 
///   RADIX of the internal representation. e.g. is RADIX is BASE_10 then d can
///   be in the range of 0..10. If base is BASE_2 the d can only be in hte range \
///   from 0..2
//
static std::string _int_precision_usub_short( int *result, std::string *src1, unsigned int d )
   {
   unsigned short ireg = RADIX;
   std::string::reverse_iterator r1_pos;
   std::string::iterator d_pos;
   std::string des1;

   if( d > RADIX )
      {
      throw int_precision::out_of_range();
      des1.insert( (std::string::size_type)0, 1, ICHARACTER(0) );
      return des1;
      }

   if( d == 0 ) // Nothing to subtract
      {
      *result = 0;
      return *src1;
      }

   des1.erase();
   des1.reserve( src1->capacity() );  // Reserver space to avoid time consuming reallocation
   d_pos = des1.begin();
   r1_pos = src1->rbegin();

   ireg = RADIX - 1 + IDIGIT( *r1_pos ) - d + ICARRY( ireg );
   d_pos = des1.insert( d_pos, ICHARACTER( ISINGLE( ireg ) ) );
   for( ++r1_pos; ICARRY( ireg ) && r1_pos != src1->rend(); ++r1_pos )
      {
      ireg = RADIX - 1 + IDIGIT( *r1_pos ) + ICARRY( ireg );
      d_pos = des1.insert( d_pos, ICHARACTER( ISINGLE( ireg ) ) );
      }

   _int_precision_strip_leading_zeros( &des1 );
   
   *result = ICARRY( ireg ) - 1;
   return des1;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/14/2005
///	@brief 	std::string _int_precision_usub
///	@return 	std::string	-	the result of subtracting src2 from src1
///	@param   "src1"	-	First unsigned source argument
///	@param   "src2"	-	Second unsigned source argument
///   @param   "result" - Return indicate wrap around (-1) otherwise 0
///
///	@todo
///
/// Description:
///   Subtract two unsigned decimal strings
///   if src1 < src2 return -1 (wrap around) otherwise return 0 (no wrap around)
//
static std::string _int_precision_usub( int *result, std::string *src1, std::string *src2 )
   {
   unsigned short ireg = RADIX;
   std::string::reverse_iterator r1_pos, r2_pos;
   std::string::iterator d_pos;
   std::string des1;

   des1.erase();
   if( src1->length() > src2->length() )
      des1.reserve( src1->capacity() );  // Reserver space to avoid time consuming reallocation
   else
      des1.reserve( src2->capacity() );  // Reserver space to avoid time consuming reallocation
   d_pos = des1.begin();
   r1_pos = src1->rbegin();
   r2_pos = src2->rbegin();

   for(; r1_pos != src1->rend() || r2_pos != src2->rend();)
      {
      if( r1_pos != src1->rend() && r2_pos != src2->rend() )
         { ireg = RADIX - 1 + IDIGIT( *r1_pos ) - IDIGIT( *r2_pos ) + ICARRY( ireg ); ++r1_pos, ++r2_pos; }
      else
         if( r1_pos != src1->rend() )
            { ireg = RADIX - 1 + IDIGIT( *r1_pos ) + ICARRY( ireg ); ++r1_pos; }
         else
            { ireg = RADIX - 1 - IDIGIT( *r2_pos ) + ICARRY( ireg ); ++r2_pos; }
      d_pos = des1.insert( d_pos, ICHARACTER( ISINGLE( ireg ) ) );
      }

   _int_precision_strip_leading_zeros( &des1 );
   
   *result = ICARRY( ireg ) - 1;
   return des1;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/14/2005
///	@brief 		std::string _int_precision_umul_short
///	@return 		std::string - 	the result of the short multiplication
///	@param      "src1"	-	Source string to multiply short number
///	@param      "d"	   -	Number to multiply   
///
///	@todo
///
/// Description:
///   Short Add: The digit d [0..RADIX] is multiplied to the unsigned decimal string
///   Optimized Multiply with zero yields zero;
///   Please note that umul_short will throw an exception if d is larger than the 
///   RADIX of the internal representation. e.g. is RADIX is BASE_10 then d can
///   be in the range of 0..10. If base is BASE_2 the d can only be in hte range \
///   from 0..2
//
static std::string _int_precision_umul_short( std::string *src1, unsigned int d )
   {
   unsigned short ireg = 0;
   std::string::reverse_iterator r1_pos;
   std::string::iterator d_pos;
   std::string des1;

   if( d > RADIX )
      {
      throw int_precision::out_of_range();
      des1.insert( (std::string::size_type)0, 1, ( ICHARACTER(0) ) );
      return des1;
      }

   if( d == 0 )
      {
      des1.insert( (std::string::size_type)0, 1, ( ICHARACTER(0) ) );
      return des1;
      }

   if( d == RADIX )  
      {
      des1.insert( (std::string::size_type)0, 1, ( ICHARACTER(0) ) );
      des1 = *src1 + des1;
      _int_precision_strip_leading_zeros( &des1 );
      return des1;
      }

   des1.erase();
   des1.reserve( src1->capacity() );  // Reserver space to avoid time consuming reallocation   
   d_pos = des1.begin();
   r1_pos = src1->rbegin();
   
   for(; r1_pos != src1->rend(); ++r1_pos )
      {
      ireg = IDIGIT( *r1_pos ) * d + ICARRY( ireg );
      d_pos = des1.insert( d_pos, ICHARACTER( ISINGLE( ireg ) ) );
      }

   if( ICARRY( ireg ) != 0 )
      d_pos = des1.insert( d_pos, ICHARACTER( ICARRY( ireg ) ) );

   _int_precision_strip_leading_zeros( &des1 );

   return des1;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/14/2005
///	@brief 	std::string _int_precision_umul
///	@return 	std::string	-	the result of multiplying src1 and src2
///	@param   "src1"	-	First unsigned source argument
///	@param   "src2"	-	Second unsigned source argument
///
///	@todo
///
/// Description:
///   Multiply two unsigned decimal strings
//
static std::string _int_precision_umul( std::string *src1, std::string *src2 )
   {
   unsigned short ireg = 0;
   int disp;
   std::string des1, tmp;
   std::string::reverse_iterator r_pos2;
   
   r_pos2 = src2->rbegin();
   des1 = _int_precision_umul_short( src1, IDIGIT( *r_pos2 ) );
   for( r_pos2++, disp = 1; r_pos2 != src2->rend(); disp++, r_pos2++ )
      {
      if( IDIGIT( *r_pos2 ) != 0 )
         {
         tmp = _int_precision_umul_short( src1, IDIGIT( *r_pos2 ) );
         tmp.append( disp, ICHARACTER( 0 ) );
         des1 = _int_precision_uadd( &des1, &tmp );
         }
      }

   _int_precision_strip_leading_zeros( &des1 );

   return des1;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/14/2005
///	@brief 	std::string _int_precision_umul_fourier
///	@return 	std::string	-	the result of multplying src1 and src2
///	@param   "src1"	-	First unsigned source argument
///	@param   "src2"	-	Second unsigned source argument
///
///	@todo
///
/// Description:
///   Multiply two unsigned decimal strings
///   Optimized: Used FFT algorithm to performed the multiplication
//
static std::string _int_precision_umul_fourier( std::string *src1, std::string *src2 )
   {
   unsigned short ireg = 0;
   std::string des1;
   std::string::iterator pos;
   unsigned int n, l, l1, l2;
   int j;
   double *a, *b, cy;
   
   l1 = src1->length();
   l2 = src2->length();
   l = l1 < l2 ? l2 : l1;
   for( n = 1; n < l; n <<= 1 ) ;
   n <<= 1;
   a = new double [n];
   b = new double [n];
   for( l=0, pos = src1->begin(); pos != src1->end(); ++pos ) a[l++] = (double)IDIGIT(*pos);
   for( ; l < n; ) a[l++] = (double)0;
   for( l=0, pos = src2->begin(); pos != src2->end(); ++pos ) b[l++] = (double)IDIGIT(*pos);
   for( ; l < n; ) b[l++] = (double)0;
   _int_real_fourier( a, n, 1 );
   _int_real_fourier( b, n, 1 );
   b[0] *= a[0];
   b[1] *= a[1];
   for( j = 2; j < n; j += 2 )
      {
      double t;
      b[j]=(t=b[j])*a[j]-b[j+1]*a[j+1];
      b[j+1]=t*a[j+1]+b[j+1]*a[j];
      }
   _int_real_fourier( b, n, -1 );
   for( cy=0, j=n-1; j >= 0; j-- )
      {
      double t;
      t=b[j]/(n>>1)+cy+0.5;
      cy=(unsigned long)( t/ RADIX );
      b[j]=t-cy*RADIX;
      }

   ireg = cy;
   if( ireg != 0 )
      des1.append( 1, ICHARACTER( ireg ) );
   for( j = 0; j < l1 + l2 -1; j++ )
      des1.append( 1, ICHARACTER( b[ j ] ) );
   
   _int_precision_strip_leading_zeros( &des1 );

   delete [] a;
   delete [] b;

   return des1;
   }

// Short Division: The digit d [1..RADIX] is divide up into the unsigned decimal string
//
///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/14/2005
///	@brief 		std::string _int_precision_udiv_short
///	@return 		std::string - 	the result of the short division
///	@param      "src1"	-	Source string to divide with the short number
///	@param      "d"	   -	Number to divide
///   @param      "remaind" - The ramind of the short division
///
///	@todo
///
/// Description:
///   Short divide: The digit d [0..RADIX] is divided up in the unsigned decimal string
///   Divide with zero throw an exception
///   Please note that udiv_short will throw an exception if d is larger than the 
///   RADIX of the internal representation. e.g. is RADIX is BASE_10 then d can
///   be in the range of 0..10. If base is BASE_2 the d can only be in hte range \
///   from 0..2
//
static std::string _int_precision_udiv_short( unsigned int *remaind, std::string *src1, unsigned int d )
   {
   int i, ir;
   std::string::iterator s1_pos;
   std::string des1;
   
   if( d > RADIX )
      {
      throw int_precision::out_of_range();
      des1.insert( (std::string::size_type)0, 1, ICHARACTER(0) );
      return des1;
      }

   if( d == 0 )
      {
      throw int_precision::divide_by_zero();
      des1.insert( (std::string::size_type)0, 1, ICHARACTER(0) );
      return des1;
      }

   des1.erase();
   des1.reserve( src1->capacity() );  // Reserver space to avoid time consuming reallocation
   s1_pos = src1->begin();
   
   ir = 0;
   for(; s1_pos != src1->end(); ++s1_pos )
      {
      i = RADIX * ir + IDIGIT( *s1_pos );
      des1 += ICHARACTER( (unsigned char)( i / d ) );
      ir = i % d;
      }

   _int_precision_strip_leading_zeros( &des1 );

   *remaind = ir;
   return des1;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/14/2005
///	@brief 	std::string _int_precision_udiv
///	@return 	std::string	-	the result of disivison
///	@param   "src1"	-	First unsigned source argument
///	@param   "src2"	-	Second unsigned source argument
///
///	@todo
///
/// Description:
///   Divide two unsigned decimal strings
///   Optimized: Used early out add and multiplication w. zero
//
static std::string _int_precision_udiv( std::string *src1, std::string *src2 )
   {
   int wrap, plusdigit;
   std::string des, quotient, divisor;
   
   des = ICHARACTER(0);
   divisor = *src1;
   if( src2->length() == 1 ) // Make short div 
      return _int_precision_udiv_short( (unsigned int *)&wrap, &divisor, IDIGIT( (*src2)[0] ) );

   plusdigit = (int)divisor.length() - (int)src2->length();
   for(  ;plusdigit > 1; )
      {
      std::string tmp;

      quotient = (char)ICHARACTER(1);
      quotient.append( plusdigit, ICHARACTER( 0 ) );
      tmp = _int_precision_umul_fourier( src2, &quotient );
      if( _int_precision_compare( &divisor, &tmp ) < 0 )
         { // Too much reduce with one power of radix
         plusdigit--;
         quotient = (char)ICHARACTER(1);
         quotient.append( plusdigit, ICHARACTER( 0 ) );
         tmp = _int_precision_umul_fourier( src2, &quotient );
         }
      divisor = _int_precision_usub( &wrap, &divisor, &tmp );
      des = _int_precision_uadd( &des, &quotient );
      plusdigit = (int)divisor.length() - (int)src2->length();
      }
   for( wrap = 0; wrap == 0; )
      {
      divisor = _int_precision_usub( &wrap, &divisor, src2 );
      if( wrap == 0 ) // src1 was indeed > src2
         des = _int_precision_uadd_short( &des, 1 );
      }

   _int_precision_strip_leading_zeros( &des );

   return des;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/14/2005
///	@brief 	std::string _int_precision_urem
///	@return 	std::string	-	the remaing result of divide src1 with src2
///	@param   "src1"	-	First unsigned source argument
///	@param   "src2"	-	Second unsigned source argument
///
///	@todo
///
/// Description:
///   Find the remainder when divide two unsigned decimal strings
///   Optimized: Used early out add and multiplication w. zero
//
static std::string _int_precision_urem( std::string *src1, std::string *src2 )
   {
   int wrap, plusdigit;
   std::string des, quotient, divisor;
   
   des = ICHARACTER(0);
   divisor = *src1;
   if( src2->length() == 1 ) // Make short rem 
      {
      unsigned int rem;
      _int_precision_udiv_short( &rem, &divisor, IDIGIT( (*src2)[0] ) );
      des = ICHARACTER( rem );
      return des;
      }

   plusdigit = (int)src1->length() - (int)src2->length();
   for( ; plusdigit > 1; )
      {
      std::string tmp;

      quotient = (char)ICHARACTER(1);
      quotient.append( plusdigit, ICHARACTER( 0 ) );
      tmp = _int_precision_umul_fourier( src2, &quotient );
      if( _int_precision_compare( &divisor, &tmp ) < 0 )
         { // Too much reduce with one power of radix
         plusdigit--;
         quotient = (char)ICHARACTER(1);
         quotient.append( plusdigit, ICHARACTER( 0 ) );
         tmp = _int_precision_umul_fourier( src2, &quotient );
         }
      divisor = _int_precision_usub( &wrap, &divisor, &tmp );
      des = _int_precision_uadd( &des, &quotient );
      plusdigit = (int)divisor.length() - (int)src2->length();
      }

   for( wrap = 0; wrap == 0; )
      {
      des = divisor;
      divisor = _int_precision_usub( &wrap, &divisor, src2 );
      }

   _int_precision_strip_leading_zeros( &des );

   return des;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  1/14/2005
///	@brief 			std::string _int_precision_itoa
///	@return 			std::string -	Return the inter precision as a string
///	@param         "a"	-	the internal integer precision string
///
///	@todo 
///
/// Description:
///   Convert int_precsion string to ascii string
///   Based on RADIX convertion from RADIX to BASE_10
///   The string has a leading sign
//
static std::string _int_precision_itoa( const std::string *a )
   {
   unsigned int rem;
   std::string s, src;
   std::string c0;

   c0.insert( (std::string::size_type)0, 1, ICHARACTER( 0 ) );
   src = *a;
   s.erase();
   s.reserve( src.capacity() );
   s.append( src, 0, 1 );     // Copy sign
   src.erase( src.begin() );  // Erase sign
   if( RADIX == BASE_10 )     // Nothing to convert
      s += src;
   else
		if( RADIX > BASE_10 )
			{
			for( ; _int_precision_compare( &src, &c0 ) != 0;  )
				{
				src = _int_precision_udiv_short( &rem, &src, BASE_10 );
		      s.insert( (std::string::size_type)1, 1, (char)ICHARACTER10( rem ) );
			   }
			}
		else
         { // Convert RADIX 2..9
			int number;
			std::string base_10, tmp_rem;
			std::string::iterator pos;
			char buf[16];
			
			itoa( BASE_10, &buf[0], RADIX );
			base_10 = std::string( buf );
			
			for( ; _int_precision_compare( &src, &c0 ) != 0;  )
				{
				tmp_rem = _int_precision_urem( &src, &base_10 ); 
				src = _int_precision_udiv( &src, &base_10 );
				// Convert tmp_rem [0..RADIX-1] into text
				number = 0;
				for( pos = tmp_rem.begin(); pos != tmp_rem.end(); ++pos )
					{
					number *= RADIX;
					number += IDIGIT( *pos );
					}
		      s.insert( (std::string::size_type)1, 1, (char)ICHARACTER10( number ) );
			   }
			}

   return s;
   }


///	@author Henrik Vestermark (hve@hvks.com)
///	@date  9/7/2004
///	@brief 			std::string _int_precision_atoi
///	@return 			string	-	The integer precision string
///	@param "str"	-	The arbitrary precision string as a regular c-string
///
///	@todo  
///
/// Description:
/// Convert ascii string to string number
/// A leading 0 is intepreted as a octal number
/// a leading 0x is interpreted as a hexadecimal number 
/// a leading 0b is interpreted as a binary number
/// otherwise it's a decimal number.
/// The resulting number is stored in BASE RADIX (10 or 256)
//
static std::string _int_precision_atoi( const char *str )
   {
   int sign;
   std::string s(str);
   std::string::iterator pos;
   std::string number;

   sign = CHAR_SIGN( '+' );;
   pos = s.begin();
   if( *pos == '+' || *pos == '-' )
      {
      sign = CHAR_SIGN( *pos );
      ++pos;
      if( pos == s.end() )
         { throw int_precision::bad_int_syntax(); return s; }
      }

   if( *pos == '0' ) // Octal, binary or hex representation
      {
      if( pos+1 != s.end() && tolower( pos[1] ) == 'x' )
         {
         for( pos += 2; pos != s.end(); ++pos )
            if( ( *pos < '0' || *pos > '9' ) && ( tolower( *pos ) < 'a' || tolower( *pos ) > 'f' ) )
               {  throw int_precision::bad_int_syntax(); return s; }
            else
               {
               char buf[ 16 ];
               std::string tmp;

               int hexvalue = IDIGIT10( *pos );
               if( hexvalue > 10 )
                  hexvalue = tolower( *pos ) - 'a' + 10;
               itoa( BASE_16, &buf[ 0 ], BASE_10 );
               tmp = buf;
               number = _int_precision_umul_fourier( &number, &tmp );

               itoa( hexvalue, &buf[ 0 ], BASE_10 );
               tmp = buf;
               number = _int_precision_uadd( &number, &tmp );
               }
         number.insert( (std::string::size_type)0, SIGN_STRING( sign ) );
         }
      else
	      if( pos+1 != s.end() && tolower( pos[1] ) == 'b' )
				{
				for( pos += 2; pos != s.end(); ++pos )
					if( *pos < '0' || *pos > '1'  )
						{  throw int_precision::bad_int_syntax(); return s; }
					else
						{
			         number = _int_precision_umul_short( &number, BASE_2 );
				      number = _int_precision_uadd_short( &number, IDIGIT10( *pos ) );
					   }
				number.insert( (std::string::size_type)0, SIGN_STRING( sign ) );
				}
			else
				{ // Collect octal represenation
				for( ; pos != s.end(); ++pos )
					if( *pos < '0' || *pos > '7' )
						{ throw int_precision::bad_int_syntax(); return s; }
	            else
		            {
			         number = _int_precision_umul_short( &number, BASE_8 );
				      number = _int_precision_uadd_short( &number, IDIGIT10( *pos ) );
					   }
				number.insert( (std::string::size_type)0, SIGN_STRING( sign ) );
				}
      }
   else
      { // Collect decimal representation
      for( ; pos != s.end(); ++pos )
         if( *pos < '0' || *pos > '9' )
            {  throw int_precision::bad_int_syntax(); return s; }
         else
            {
            number = _int_precision_umul_short( &number, BASE_10 );
            number = _int_precision_uadd_short( &number, IDIGIT10( *pos ) );
            }
      number.insert( (std::string::size_type)0, SIGN_STRING( sign ) );
      }

   return number;
   }

   
#endif